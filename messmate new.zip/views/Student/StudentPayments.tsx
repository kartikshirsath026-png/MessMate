
import React, { useState } from 'react';
import { Student, Payment, CanteenContact, SubscriptionPlan } from '../../types';
import { SUBSCRIPTION_PRANS_INFO } from '../../constants';

interface StudentPaymentsProps {
  student: Student;
  setStudents: (s: Student[]) => void;
  allStudents: Student[];
  contact: CanteenContact;
}

const StudentPayments: React.FC<StudentPaymentsProps> = ({ student, setStudents, allStudents, contact }) => {
  const [selectedPlan, setSelectedPlan] = useState<SubscriptionPlan>(student.subscriptionPlan || SubscriptionPlan.MONTHLY_DOUBLE);

  const handlePayment = () => {
    const planInfo = SUBSCRIPTION_PRANS_INFO[selectedPlan];
    if (confirm(`Confirm payment of ₹${planInfo.price} for ${planInfo.name} to ${contact.ownerName}?`)) {
      const newPayment: Payment = {
        id: `p-${Date.now()}`,
        amount: planInfo.price,
        date: new Date().toISOString().split('T')[0],
        month: new Intl.DateTimeFormat('en-US', { month: 'long' }).format(new Date()),
        status: 'PAID'
      };

      const updatedStudents = allStudents.map(s => {
        if (s.rollNo === student.rollNo) {
          const expiryDate = new Date();
          expiryDate.setDate(expiryDate.getDate() + 30);
          
          return {
            ...s,
            membershipActive: true,
            subscriptionPlan: selectedPlan,
            lastPaymentDate: newPayment.date,
            subscriptionExpiryDate: expiryDate.toISOString().split('T')[0],
            payments: [newPayment, ...s.payments],
            attendance: [] 
          };
        }
        return s;
      });

      setStudents(updatedStudents);
      alert('Payment confirmed! Your subscription has been updated.');
    }
  };

  const calculateRemainingDays = () => {
    if (!student.subscriptionExpiryDate) return 0;
    const expiry = new Date(student.subscriptionExpiryDate);
    const now = new Date();
    const diffTime = expiry.getTime() - now.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return Math.max(0, diffDays);
  };

  const remainingDays = calculateRemainingDays();

  return (
    <div className="space-y-8 max-w-6xl pb-12">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Subscription Plans */}
        <div className="bg-slate-900 p-8 rounded-[40px] border border-slate-800 shadow-2xl flex flex-col">
          <h3 className="text-white font-black text-xl mb-6 tracking-tight">Choose Your Plan</h3>
          <div className="space-y-4 flex-1">
            {(Object.entries(SUBSCRIPTION_PRANS_INFO) as [SubscriptionPlan, any][]).map(([key, info]) => (
              <button
                key={key}
                onClick={() => setSelectedPlan(key)}
                className={`w-full p-4 rounded-2xl border transition-all text-left flex justify-between items-center ${
                  selectedPlan === key 
                    ? 'bg-orange-600/20 border-orange-500 text-white' 
                    : 'bg-slate-800/40 border-slate-800 text-slate-400 hover:border-slate-700'
                }`}
              >
                <div>
                  <p className="font-bold text-sm">{info.name}</p>
                  <p className="text-[10px] opacity-60">{info.description}</p>
                </div>
                <p className="font-black text-lg">₹{info.price}</p>
              </button>
            ))}
          </div>
          
          <div className="mt-8 p-6 bg-slate-950 rounded-3xl border border-slate-800">
            <div className="flex justify-between items-center mb-2">
              <span className="text-slate-500 text-[10px] font-bold uppercase tracking-widest">Remaining Days</span>
              <span className="text-orange-500 font-black">{remainingDays} Days</span>
            </div>
            <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
              <div 
                className="bg-orange-600 h-full transition-all duration-500" 
                style={{ width: `${Math.min(100, (remainingDays / 30) * 100)}%` }}
              ></div>
            </div>
            <p className="text-[10px] text-slate-600 mt-3 text-center uppercase font-bold tracking-widest">
              Expires: {student.subscriptionExpiryDate || 'N/A'}
            </p>
          </div>

          <button 
            onClick={handlePayment}
            className="w-full py-5 bg-orange-600 hover:bg-orange-700 text-white rounded-2xl font-black mt-6 shadow-xl transition-all transform active:scale-95 border border-orange-500"
          >
            RENEW WITH SELECTED PLAN
          </button>
        </div>

        {/* QR Scanner Card */}
        <div className="bg-slate-900 p-10 rounded-[40px] border border-slate-800 shadow-2xl flex flex-col items-center justify-center text-center">
           <h4 className="text-white font-black text-xl mb-6 tracking-tight">Digital Pay Station</h4>
           <div className="relative group">
              <div className="absolute inset-0 bg-orange-500 blur-[40px] opacity-10"></div>
              <div className="relative w-56 h-56 bg-white p-4 rounded-[32px] shadow-2xl flex items-center justify-center">
                 {contact.qrCode ? (
                   <img src={contact.qrCode} alt="Scanner" className="w-full h-full object-contain" />
                 ) : (
                   <div className="text-slate-300 flex flex-col items-center">
                     <span className="text-4xl mb-2">🚫</span>
                     <span className="text-[10px] font-bold uppercase">QR Not Configured</span>
                   </div>
                 )}
              </div>
           </div>
           
           <div className="mt-8 space-y-2">
             <p className="text-[10px] text-slate-500 font-bold uppercase tracking-[2px]">Payee Details</p>
             <p className="font-black text-white text-lg">{contact.ownerName}</p>
             <div className="flex items-center gap-2 justify-center">
                <span className="bg-slate-800 text-orange-400 px-4 py-1.5 rounded-full font-mono text-sm border border-slate-700 select-all">
                  {contact.upiId}
                </span>
             </div>
           </div>
           <p className="text-[10px] text-slate-500 mt-8 leading-relaxed font-medium uppercase tracking-widest max-w-[200px]">
             Screenshot your receipt for verification
           </p>
        </div>

        {/* Transaction History */}
        <div className="bg-slate-900 p-10 rounded-[40px] border border-slate-800 shadow-2xl flex flex-col">
          <h3 className="text-white font-black text-xl mb-8 tracking-tight">Ledger History</h3>
          <div className="flex-1 space-y-4 overflow-y-auto max-h-[400px] pr-2">
            {student.payments.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-20 text-slate-600">
                <span className="text-4xl mb-2">📁</span>
                <p className="text-[10px] font-bold uppercase tracking-widest">No Records Found</p>
              </div>
            ) : (
              student.payments.map(p => (
                <div key={p.id} className="flex items-center justify-between p-5 bg-slate-800/40 rounded-2xl border border-slate-800 group hover:border-slate-700 transition-all">
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 bg-green-500/10 border border-green-500/20 rounded-xl flex items-center justify-center text-green-500 text-lg">✓</div>
                    <div>
                      <p className="text-sm font-black text-slate-100">{p.month}</p>
                      <p className="text-[10px] text-slate-500 font-bold">{p.date}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-black text-white">₹{p.amount}</p>
                    <p className="text-[9px] text-green-500 font-black tracking-widest uppercase">Verified</p>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default StudentPayments;
