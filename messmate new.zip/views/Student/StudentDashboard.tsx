
import React, { useState, useEffect } from 'react';
import { Student, Notice, AttendanceRecord, CanteenContact, MenuItem } from '../../types';
import { geminiService } from '../../services/geminiService';

interface StudentDashboardProps {
  student: Student;
  notices: Notice[];
  canteenStatus: 'OPEN' | 'CLOSED' | 'BUSY';
  updateStudent: (s: Student) => void;
  contact: CanteenContact;
  menu: MenuItem[];
}

const StudentDashboard: React.FC<StudentDashboardProps> = ({ student, notices, canteenStatus, updateStudent, contact, menu }) => {
  const [rsvp, setRsvp] = useState<'YES' | 'NO' | 'PENDING'>(student.rsvpStatus || 'PENDING');
  const [nutrition, setNutrition] = useState<any>(null);
  const [isAnalyzingNutrition, setIsAnalyzingNutrition] = useState(false);

  useEffect(() => {
    const analyzeTodayMenu = async () => {
      if (menu.length > 0) {
        setIsAnalyzingNutrition(true);
        const result = await geminiService.analyzeNutrition(menu);
        setNutrition(result);
        setIsAnalyzingNutrition(false);
      }
    };
    analyzeTodayMenu();
  }, [menu]);

  const handleRsvp = (status: 'YES' | 'NO') => {
    const today = new Date().toISOString().split('T')[0];
    const existingAttendance = student.attendance || [];
    const otherAttendance = existingAttendance.filter(a => a.date !== today);
    
    let newCredits = student.ecoCredits || 0;
    if (status === 'NO' && rsvp !== 'NO') {
      newCredits += 20; 
    }

    const newRecord: AttendanceRecord = {
      date: today,
      status: status === 'YES' ? 'PRESENT' : 'ABSENT'
    };

    const updatedStudent: Student = {
      ...student,
      rsvpStatus: status,
      ecoCredits: newCredits,
      attendance: [...otherAttendance, newRecord]
    };

    setRsvp(status);
    updateStudent(updatedStudent);
  };

  const calculateRemainingDays = () => {
    if (!student.subscriptionExpiryDate) return 0;
    const expiry = new Date(student.subscriptionExpiryDate);
    const now = new Date();
    const diffTime = expiry.getTime() - now.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return Math.max(0, diffDays);
  };

  const remainingDays = calculateRemainingDays();

  return (
    <div className="space-y-6">
      {/* Reminders & Alerts */}
      <div className="space-y-3">
        {remainingDays <= 3 && (
          <div className="bg-red-500/10 border border-red-500/20 p-4 rounded-2xl flex items-center justify-between animate-pulse">
            <div className="flex items-center gap-3">
              <span className="text-xl">⚠️</span>
              <div>
                <p className="text-xs font-bold text-red-400 uppercase tracking-widest">Subscription Alert</p>
                <p className="text-sm text-slate-200">Your subscription expires in {remainingDays} days. Please renew soon!</p>
              </div>
            </div>
            <button className="bg-red-600 text-white px-4 py-1.5 rounded-xl text-xs font-bold hover:bg-red-700 transition-all">Renew Now</button>
          </div>
        )}
        {rsvp === 'PENDING' && (
          <div className="bg-orange-500/10 border border-orange-500/20 p-4 rounded-2xl flex items-center gap-3">
            <span className="text-xl">🔔</span>
            <div>
              <p className="text-xs font-bold text-orange-400 uppercase tracking-widest">RSVP Reminder</p>
              <p className="text-sm text-slate-200">Please confirm if you are coming for today's meal to help reduce food waste.</p>
            </div>
          </div>
        )}
      </div>

      {/* Sustainability Header */}
      <div className="flex justify-between items-center bg-slate-900 border border-slate-800 p-4 rounded-3xl mb-2">
        <div className="flex items-center gap-3">
          <span className="text-2xl">🌱</span>
          <div>
            <p className="text-[10px] font-black text-emerald-500 uppercase tracking-widest">Sustainability Rank</p>
            <p className="text-sm font-bold text-white">Eco Warrior: {student.ecoCredits || 0} Points</p>
          </div>
        </div>
        <div className="w-24 bg-slate-800 h-2 rounded-full overflow-hidden">
          <div className="bg-emerald-500 h-full" style={{ width: `${Math.min((student.ecoCredits || 0) % 100, 100)}%` }}></div>
        </div>
      </div>

      <div className="bg-slate-900 p-8 rounded-[40px] text-white shadow-2xl flex flex-col md:flex-row justify-between items-center gap-8 border border-slate-800 relative overflow-hidden group">
        <div className="absolute top-[-50%] left-[-20%] w-[100%] h-[200%] bg-orange-600/5 blur-[120px] rounded-full pointer-events-none"></div>
        
        <div className="relative z-10 text-center md:text-left w-full">
          <h2 className="text-4xl font-black mb-2 tracking-tight">Hello, <span className="text-orange-500">{student.name.split(' ')[0]}</span></h2>
          <p className="text-slate-400 font-medium max-w-lg mx-auto md:mx-0">Welcome back! Manage your meals and help us reduce food waste by RSVPing early. Earn eco-credits for every meal you skip.</p>
          
          <div className="mt-8 flex flex-wrap gap-4 justify-center md:justify-start">
             <button 
               onClick={() => handleRsvp('YES')}
               className={`px-8 py-3.5 rounded-2xl text-sm font-black transition-all transform active:scale-95 ${
                 rsvp === 'YES' 
                 ? 'bg-orange-600 text-white shadow-lg border border-orange-500' 
                 : 'bg-slate-800 text-slate-300 border border-slate-700 hover:bg-slate-700'
               }`}
             >
               ✓ Going Today
             </button>
             <button 
               onClick={() => handleRsvp('NO')}
               className={`px-8 py-3.5 rounded-2xl text-sm font-black transition-all transform active:scale-95 ${
                 rsvp === 'NO' 
                 ? 'bg-emerald-600 text-white shadow-lg border border-emerald-500' 
                 : 'bg-slate-800 text-slate-300 border border-slate-700 hover:bg-slate-700'
               }`}
             >
               ✕ Skipping Today
             </button>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <div className="bg-slate-900 p-8 rounded-3xl border border-slate-800 shadow-xl group hover:border-orange-500/30 transition-all">
           <h3 className="font-bold text-white mb-6 flex items-center gap-3">
             <span className="p-2 bg-orange-600/10 text-orange-500 rounded-2xl border border-orange-600/20">🍛</span>
             Today's Special
           </h3>
           <div className="space-y-4">
             <div className="flex items-center gap-5 p-5 bg-slate-800/50 rounded-2xl border border-slate-800 border-l-4 border-l-orange-500">
               <div className="w-12 h-12 bg-slate-800 rounded-xl flex items-center justify-center text-2xl shadow-inner border border-slate-700">🥘</div>
               <div>
                  <h4 className="font-bold text-slate-100 text-sm mb-0.5">Indian Thali</h4>
                  <p className="text-xs text-slate-500 leading-relaxed">Rajma Chawal, Roti, Salad & Curd</p>
               </div>
             </div>
             {nutrition && (
               <div className="p-4 bg-indigo-900/10 rounded-2xl border border-indigo-500/20 animate-in fade-in slide-in-from-bottom-2">
                 <p className="text-[10px] text-indigo-400 font-bold uppercase tracking-widest mb-3">AI Nutrition Analysis</p>
                 <div className="grid grid-cols-2 gap-3">
                   <div className="bg-slate-950/50 p-2 rounded-xl text-center">
                     <p className="text-xs text-slate-500">Calories</p>
                     <p className="text-sm font-bold text-slate-200">{nutrition.calories} kcal</p>
                   </div>
                   <div className="bg-slate-950/50 p-2 rounded-xl text-center">
                     <p className="text-xs text-slate-500">Protein</p>
                     <p className="text-sm font-bold text-slate-200">{nutrition.protein}g</p>
                   </div>
                   <div className="bg-slate-950/50 p-2 rounded-xl text-center">
                     <p className="text-xs text-slate-500">Carbs</p>
                     <p className="text-sm font-bold text-slate-200">{nutrition.carbs}g</p>
                   </div>
                   <div className="bg-slate-950/50 p-2 rounded-xl text-center">
                     <p className="text-xs text-slate-500">Fats</p>
                     <p className="text-sm font-bold text-slate-200">{nutrition.fats}g</p>
                   </div>
                 </div>
               </div>
             )}
           </div>
        </div>

        <div className="bg-slate-900 p-8 rounded-3xl border border-slate-800 shadow-xl">
          <h3 className="font-bold text-white mb-6 flex items-center gap-3">
             <span className="p-2 bg-blue-600/10 text-blue-400 rounded-2xl border border-blue-600/20">📢</span>
             Notice Board
          </h3>
          <div className="space-y-4">
            {notices.slice(0, 3).map(notice => (
              <div key={notice.id} className="p-4 bg-slate-800/30 rounded-2xl border border-slate-800/50">
                <h4 className="font-bold text-slate-200 text-sm mb-1">{notice.title}</h4>
                <p className="text-xs text-slate-500 leading-relaxed line-clamp-1">{notice.content}</p>
              </div>
            ))}
            {notices.length === 0 && <p className="text-xs text-slate-600 italic text-center py-6">All clear! No new updates.</p>}
          </div>
        </div>

        <div className="bg-slate-900 p-8 rounded-3xl border border-slate-800 shadow-xl">
           <h3 className="font-bold text-white mb-6 flex items-center gap-3">
             <span className="p-2 bg-emerald-600/10 text-emerald-400 rounded-2xl border border-emerald-600/20">📞</span>
             Support
           </h3>
           <div className="space-y-5">
             <div className="p-5 bg-emerald-950/20 rounded-2xl border border-emerald-900/30 text-center">
                <p className="text-[10px] text-emerald-500 font-bold uppercase tracking-[2px] mb-2">Support Line</p>
                <p className="text-sm font-bold text-slate-200 mb-1">{contact.ownerName}</p>
                <a href={`tel:${contact.phone}`} className="text-2xl font-black text-white hover:text-emerald-400 transition-colors">
                  {contact.phone}
                </a>
             </div>
           </div>
        </div>
      </div>
    </div>
  );
};

export default StudentDashboard;
