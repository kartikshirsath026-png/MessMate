
import React from 'react';
import { Poll } from '../../types';

interface StudentPollsProps {
  polls: Poll[];
  setPolls: (p: Poll[]) => void;
  studentRollNo: string;
}

const StudentPolls: React.FC<StudentPollsProps> = ({ polls, setPolls, studentRollNo }) => {
  const handleVote = (pollId: string, optionId: string) => {
    setPolls(polls.map(p => {
      if (p.id === pollId && !p.votedBy.includes(studentRollNo)) {
        return {
          ...p,
          options: p.options.map(o => o.id === optionId ? { ...o, votes: o.votes + 1 } : o),
          votedBy: [...p.votedBy, studentRollNo]
        };
      }
      return p;
    }));
  };

  return (
    <div className="space-y-6 max-w-2xl mx-auto">
      <div className="text-center mb-8">
        <h2 className="text-2xl font-bold text-slate-800">Your Opinion Matters!</h2>
        <p className="text-slate-500">Vote for your favorite dishes to see them on next week's menu.</p>
      </div>

      {polls.filter(p => p.isActive).map(poll => {
        const hasVoted = poll.votedBy.includes(studentRollNo);
        const totalVotes = poll.options.reduce((sum, o) => sum + o.votes, 0);

        return (
          <div key={poll.id} className="bg-white p-8 rounded-3xl shadow-sm border border-slate-100">
            <h3 className="text-lg font-bold text-slate-800 mb-6">{poll.question}</h3>
            
            <div className="space-y-4">
              {poll.options.map(option => {
                const percentage = totalVotes > 0 ? Math.round((option.votes / totalVotes) * 100) : 0;
                
                return (
                  <button
                    key={option.id}
                    onClick={() => handleVote(poll.id, option.id)}
                    disabled={hasVoted}
                    className={`w-full relative p-4 rounded-2xl border transition-all text-left overflow-hidden ${
                      hasVoted ? 'cursor-default border-slate-100' : 'border-slate-200 hover:border-orange-500'
                    }`}
                  >
                    {hasVoted && (
                      <div 
                        className="absolute left-0 top-0 bottom-0 bg-orange-50 z-0 transition-all duration-1000"
                        style={{ width: `${percentage}%` }}
                      ></div>
                    )}
                    <div className="relative z-10 flex justify-between items-center">
                      <span className={`font-medium ${hasVoted ? 'text-slate-800' : 'text-slate-600'}`}>
                        {option.text}
                      </span>
                      {hasVoted && (
                        <span className="text-orange-600 font-bold text-sm">{percentage}%</span>
                      )}
                    </div>
                  </button>
                );
              })}
            </div>

            {hasVoted ? (
              <p className="mt-6 text-center text-sm text-green-600 font-medium">✓ You have already voted. Thanks for contributing!</p>
            ) : (
              <p className="mt-6 text-center text-xs text-slate-400 italic">Voting is anonymous. You can only vote once per poll.</p>
            )}
          </div>
        );
      })}

      {polls.filter(p => p.isActive).length === 0 && (
        <div className="bg-white p-12 rounded-3xl text-center border border-dashed border-slate-200">
           <span className="text-4xl mb-4 block">😴</span>
           <p className="text-slate-500">No active polls right now. Check back later!</p>
        </div>
      )}
    </div>
  );
};

export default StudentPolls;
