
import React, { useState } from 'react';
import { Feedback } from '../../types';

interface StudentFeedbackProps {
  rollNo: string;
  name: string;
  onSubmit: (f: Feedback) => void;
}

const StudentFeedback: React.FC<StudentFeedbackProps> = ({ rollNo, name, onSubmit }) => {
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const feedback: Feedback = {
      id: Date.now().toString(),
      studentRollNo: rollNo,
      studentName: name,
      rating,
      comment,
      date: new Date().toISOString().split('T')[0]
    };
    onSubmit(feedback);
    setSubmitted(true);
  };

  if (submitted) {
    return (
      <div className="max-w-md mx-auto text-center py-20">
        <div className="bg-green-100 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6">
           <span className="text-4xl text-green-600">❤</span>
        </div>
        <h2 className="text-2xl font-bold text-slate-800 mb-2">Thank You!</h2>
        <p className="text-slate-500 mb-8">Your feedback helps us serve you better food everyday.</p>
        <button 
          onClick={() => { setSubmitted(false); setComment(''); }}
          className="text-orange-600 font-bold hover:underline"
        >
          Submit another feedback
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto space-y-8">
      <div className="text-center">
        <h2 className="text-2xl font-bold text-slate-800">Share Your Experience</h2>
        <p className="text-slate-500">How was the meal today? Let us know!</p>
      </div>

      <form onSubmit={handleSubmit} className="bg-white p-8 rounded-3xl shadow-sm border border-slate-100 space-y-6">
        <div className="space-y-4">
          <label className="block text-sm font-bold text-slate-700 text-center">Rate Today's Meal</label>
          <div className="flex justify-center gap-4">
            {[1, 2, 3, 4, 5].map(star => (
              <button
                key={star}
                type="button"
                onClick={() => setRating(star)}
                className={`text-4xl transition-all transform hover:scale-110 ${star <= rating ? 'grayscale-0' : 'grayscale opacity-30'}`}
              >
                {star === 1 ? '🤢' : star === 2 ? '☹' : star === 3 ? '😐' : star === 4 ? '😋' : '😍'}
              </button>
            ))}
          </div>
          <p className="text-center text-xs font-bold text-slate-400 uppercase tracking-widest">
            {rating === 1 ? 'Terrible' : rating === 2 ? 'Poor' : rating === 3 ? 'Average' : rating === 4 ? 'Good' : 'Delicious!'}
          </p>
        </div>

        <div className="space-y-2">
          <label className="block text-sm font-bold text-slate-700">Detailed Feedback</label>
          <textarea
            required
            className="w-full h-32 p-4 rounded-2xl border border-slate-200 focus:ring-2 focus:ring-orange-500 focus:border-transparent outline-none transition-all resize-none text-slate-900"
            placeholder="Tell us what you liked or what can be improved..."
            value={comment}
            onChange={e => setComment(e.target.value)}
          ></textarea>
        </div>

        <button
          type="submit"
          className="w-full bg-slate-900 text-white font-bold py-4 rounded-2xl shadow-xl hover:bg-slate-800 transition-all"
        >
          Submit Anonymous Feedback
        </button>
        <p className="text-center text-xs text-slate-400 italic">Only the owner can see this feedback to improve services.</p>
      </form>
    </div>
  );
};

export default StudentFeedback;
