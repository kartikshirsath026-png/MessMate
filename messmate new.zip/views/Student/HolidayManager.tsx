import React, { useState } from 'react';
import { Student, HolidayApplication } from '../../types';

interface HolidayManagerProps {
  student: Student;
  holidays: HolidayApplication[];
  setHolidays: React.Dispatch<React.SetStateAction<HolidayApplication[]>>;
}

const HolidayManager: React.FC<HolidayManagerProps> = ({ student, holidays, setHolidays }) => {
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [reason, setReason] = useState('');
  const [error, setError] = useState('');

  const studentHolidays = holidays.filter(h => h.studentRollNo === student.rollNo);

  const handleApply = () => {
    if (!startDate || !endDate || !reason) {
      setError('Please fill all fields.');
      return;
    }

    const start = new Date(startDate);
    const now = new Date();
    const diffHours = (start.getTime() - now.getTime()) / (1000 * 60 * 60);

    if (diffHours < 24) {
      setError('Holidays must be applied at least 24 hours in advance.');
      return;
    }

    if (new Date(endDate) < start) {
      setError('End date cannot be before start date.');
      return;
    }

    const newHoliday: HolidayApplication = {
      id: Math.random().toString(36).substr(2, 9),
      studentRollNo: student.rollNo,
      startDate,
      endDate,
      reason,
      status: 'PENDING',
      appliedAt: new Date().toISOString()
    };

    setHolidays([...holidays, newHoliday]);
    setStartDate('');
    setEndDate('');
    setReason('');
    setError('');
    alert('Holiday application submitted successfully!');
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Holiday Management</h2>
        <div className="bg-orange-600/10 text-orange-500 px-4 py-2 rounded-xl text-sm font-medium border border-orange-500/20">
          Rule: Apply 24h in advance
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-slate-900/50 border border-slate-800 rounded-3xl p-6">
          <h3 className="text-lg font-semibold mb-4">Apply for Holiday</h3>
          <div className="space-y-4">
            {error && <div className="bg-red-500/10 border border-red-500/20 text-red-400 p-3 rounded-xl text-sm">{error}</div>}
            <div>
              <label className="text-xs text-slate-500 uppercase font-bold mb-1 block">Start Date</label>
              <input 
                type="date" 
                value={startDate}
                onChange={e => setStartDate(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2 focus:ring-2 focus:ring-orange-500 outline-none"
              />
            </div>
            <div>
              <label className="text-xs text-slate-500 uppercase font-bold mb-1 block">End Date</label>
              <input 
                type="date" 
                value={endDate}
                onChange={e => setEndDate(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2 focus:ring-2 focus:ring-orange-500 outline-none"
              />
            </div>
            <div>
              <label className="text-xs text-slate-500 uppercase font-bold mb-1 block">Reason</label>
              <textarea 
                value={reason}
                onChange={e => setReason(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2 focus:ring-2 focus:ring-orange-500 outline-none h-24 resize-none"
                placeholder="Why are you taking a holiday?"
              />
            </div>
            <button 
              onClick={handleApply}
              className="w-full bg-orange-600 hover:bg-orange-700 text-white font-bold py-3 rounded-xl transition-all"
            >
              Submit Application
            </button>
          </div>
        </div>

        <div className="md:col-span-2 bg-slate-900/50 border border-slate-800 rounded-3xl p-6">
          <h3 className="text-lg font-semibold mb-4">Your Holiday History</h3>
          {studentHolidays.length === 0 ? (
            <div className="text-center py-12 text-slate-500">
              <p>No holiday applications found.</p>
            </div>
          ) : (
            <div className="space-y-4">
              {studentHolidays.map(h => (
                <div key={h.id} className="bg-slate-950 border border-slate-800 p-4 rounded-2xl flex justify-between items-center">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-bold text-slate-200">{h.startDate}</span>
                      <span className="text-slate-600">to</span>
                      <span className="font-bold text-slate-200">{h.endDate}</span>
                    </div>
                    <p className="text-sm text-slate-500">{h.reason}</p>
                  </div>
                  <div className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                    h.status === 'APPROVED' ? 'bg-emerald-500/20 text-emerald-400' :
                    h.status === 'REJECTED' ? 'bg-red-500/20 text-red-400' :
                    'bg-slate-800 text-slate-400'
                  }`}>
                    {h.status}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default HolidayManager;
