
import React from 'react';
import { MenuItem } from '../../types';

interface StudentMenuProps {
  menu: MenuItem[];
}

const StudentMenu: React.FC<StudentMenuProps> = ({ menu }) => {
  const categories = ['Breakfast', 'Lunch', 'Snack', 'Dinner'];

  return (
    <div className="space-y-8">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {categories.map(cat => (
          <div key={cat} className="space-y-4">
            <h3 className="font-bold text-slate-400 text-xs uppercase tracking-widest px-2">{cat}</h3>
            <div className="space-y-4">
              {menu.filter(i => i.type === cat).map(item => (
                <div key={item.id} className="bg-white p-5 rounded-2xl shadow-sm border border-slate-50 flex flex-col">
                  <h4 className="font-bold text-slate-800 mb-2">{item.name}</h4>
                  {item.description && (
                    <p className="text-xs text-slate-500 mb-3 flex-1">{item.description}</p>
                  )}
                  {item.nutrition && (
                    <div className="pt-3 border-t border-slate-50 flex justify-between">
                       <span className="text-[10px] font-bold text-orange-600">⚡ {item.nutrition.calories} kcal</span>
                       <span className="text-[10px] font-bold text-indigo-600">💪 {item.nutrition.protein}g</span>
                    </div>
                  )}
                </div>
              ))}
              {menu.filter(i => i.type === cat).length === 0 && (
                <div className="p-4 bg-slate-50/50 rounded-2xl border border-dashed border-slate-200 text-center">
                  <p className="text-[10px] text-slate-400 italic">No {cat} items</p>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default StudentMenu;