
import React, { useState } from 'react';
import { Poll } from '../../types';

interface PollManagerProps {
  polls: Poll[];
  setPolls: (p: Poll[]) => void;
}

const PollManager: React.FC<PollManagerProps> = ({ polls, setPolls }) => {
  const [showAdd, setShowAdd] = useState(false);
  const [question, setQuestion] = useState('');
  const [options, setOptions] = useState(['', '']);

  const handleAddOption = () => setOptions([...options, '']);
  const handleRemoveOption = (index: number) => setOptions(options.filter((_, i) => i !== index));
  const handleOptionChange = (index: number, val: string) => {
    const next = [...options];
    next[index] = val;
    setOptions(next);
  };

  const createPoll = () => {
    if (!question || options.some(o => !o)) {
      alert("Please fill question and all options.");
      return;
    }
    const newPoll: Poll = {
      id: Date.now().toString(),
      question,
      options: options.map((o, i) => ({ id: `opt-${i}`, text: o, votes: 0 })),
      isActive: true,
      votedBy: []
    };
    // Deactivate previous polls
    setPolls([newPoll, ...polls.map(p => ({ ...p, isActive: false }))]);
    setShowAdd(false);
    setQuestion('');
    setOptions(['', '']);
  };

  const togglePoll = (id: string) => {
    setPolls(polls.map(p => p.id === id ? { ...p, isActive: !p.isActive } : p));
  };

  const deletePoll = (id: string) => {
    if (confirm("Delete this poll?")) setPolls(polls.filter(p => p.id !== id));
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h3 className="font-bold text-slate-800">Canteen Voting System</h3>
        <button 
          onClick={() => setShowAdd(true)}
          className="bg-slate-900 text-white px-4 py-2 rounded-xl text-sm font-semibold"
        >
          Create New Poll
        </button>
      </div>

      {showAdd && (
        <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-xl">
          <h4 className="font-bold mb-4">New Food Poll</h4>
          <div className="space-y-4">
            <input 
              placeholder="Question (e.g. Next Sunday Special?)" 
              className="w-full px-4 py-2 border rounded-xl outline-none focus:ring-2 focus:ring-orange-500 text-slate-900"
              value={question}
              onChange={e => setQuestion(e.target.value)}
            />
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-400 uppercase">Options</label>
              {options.map((opt, i) => (
                <div key={i} className="flex gap-2">
                  <input 
                    placeholder={`Option ${i+1}`}
                    className="flex-1 px-4 py-2 border rounded-xl outline-none text-slate-900"
                    value={opt}
                    onChange={e => handleOptionChange(i, e.target.value)}
                  />
                  {options.length > 2 && (
                    <button onClick={() => handleRemoveOption(i)} className="text-red-400">✕</button>
                  )}
                </div>
              ))}
              <button 
                onClick={handleAddOption}
                className="text-xs text-orange-600 font-bold hover:underline"
              >
                + Add Option
              </button>
            </div>
            <div className="flex gap-3 pt-4 border-t">
              <button onClick={() => setShowAdd(false)} className="px-4 py-2 text-slate-500">Cancel</button>
              <button onClick={createPoll} className="flex-1 bg-orange-600 text-white py-2 rounded-xl font-bold">Launch Poll</button>
            </div>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {polls.map(poll => (
          <div key={poll.id} className={`bg-white p-6 rounded-3xl border transition-all ${poll.isActive ? 'border-orange-200 ring-2 ring-orange-100 shadow-lg' : 'border-slate-100 shadow-sm opacity-60'}`}>
            <div className="flex justify-between items-start mb-4">
              <h4 className="font-bold text-slate-800">{poll.question}</h4>
              <span className={`px-2 py-1 rounded-full text-[10px] font-bold ${poll.isActive ? 'bg-orange-100 text-orange-600' : 'bg-slate-100 text-slate-400'}`}>
                {poll.isActive ? 'ACTIVE' : 'CLOSED'}
              </span>
            </div>
            <div className="space-y-2 mb-6">
               {poll.options.map(o => (
                 <div key={o.id} className="flex justify-between text-xs p-2 bg-slate-50 rounded-lg">
                   <span className="text-slate-600">{o.text}</span>
                   <span className="font-bold text-slate-800">{o.votes} votes</span>
                 </div>
               ))}
            </div>
            <div className="flex justify-between items-center pt-4 border-t">
              <p className="text-[10px] text-slate-400 uppercase font-mono">Total: {poll.votedBy.length} Students</p>
              <div className="flex gap-3">
                <button onClick={() => togglePoll(poll.id)} className="text-xs font-bold text-blue-600">{poll.isActive ? 'Close' : 'Re-open'}</button>
                <button onClick={() => deletePoll(poll.id)} className="text-xs font-bold text-red-400">Delete</button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default PollManager;
