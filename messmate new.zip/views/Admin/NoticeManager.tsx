
import React, { useState } from 'react';
import { Notice } from '../../types';

interface NoticeManagerProps {
  notices: Notice[];
  setNotices: (n: Notice[]) => void;
}

const NoticeManager: React.FC<NoticeManagerProps> = ({ notices, setNotices }) => {
  const [newNotice, setNewNotice] = useState({ title: '', content: '', isImportant: false });

  const addNotice = () => {
    if (!newNotice.title || !newNotice.content) return;
    const notice: Notice = {
      id: Date.now().toString(),
      title: newNotice.title,
      content: newNotice.content,
      isImportant: newNotice.isImportant,
      date: new Date().toISOString().split('T')[0]
    };
    setNotices([notice, ...notices]);
    setNewNotice({ title: '', content: '', isImportant: false });
  };

  const markHoliday = () => {
    const holidayDate = prompt("Enter holiday date (e.g. 25th May):", "Tomorrow");
    if (!holidayDate) return;
    
    const notice: Notice = {
      id: Date.now().toString(),
      title: "🏖 Holiday Notice",
      content: `Attention Students: The Canteen will be closed on ${holidayDate} for maintenance/holiday. No meals will be served.`,
      isImportant: true,
      date: new Date().toISOString().split('T')[0]
    };
    setNotices([notice, ...notices]);
  };

  const removeNotice = (id: string) => setNotices(notices.filter(n => n.id !== id));

  return (
    <div className="space-y-8">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 bg-white p-6 rounded-2xl border border-slate-100 shadow-sm">
          <h3 className="font-bold text-slate-800 mb-6">Broadcast New Message</h3>
          <div className="space-y-4">
            <input 
              placeholder="Notice Title" 
              className="w-full px-4 py-3 rounded-xl border border-slate-200 outline-none focus:ring-2 focus:ring-orange-500 text-slate-900"
              value={newNotice.title}
              onChange={e => setNewNotice({...newNotice, title: e.target.value})}
            />
            <textarea 
              placeholder="Type your message to all students here..." 
              className="w-full h-32 px-4 py-3 rounded-xl border border-slate-200 outline-none focus:ring-2 focus:ring-orange-500 resize-none text-slate-900"
              value={newNotice.content}
              onChange={e => setNewNotice({...newNotice, content: e.target.value})}
            />
            <div className="flex flex-col md:flex-row gap-4 items-center">
              <label className="flex items-center gap-2 cursor-pointer flex-1">
                <input 
                  type="checkbox" 
                  checked={newNotice.isImportant}
                  onChange={e => setNewNotice({...newNotice, isImportant: e.target.checked})}
                  className="w-5 h-5 accent-red-600 rounded"
                />
                <span className="text-sm font-medium text-slate-600">Mark as High Priority</span>
              </label>
              <button 
                onClick={addNotice}
                className="w-full md:w-auto bg-orange-600 text-white font-bold px-8 py-3 rounded-xl hover:bg-orange-700 transition-all shadow-lg"
              >
                Send Broadcast
              </button>
            </div>
          </div>
        </div>

        <div className="bg-orange-50 p-6 rounded-2xl border border-orange-100 flex flex-col justify-center text-center">
           <div className="text-4xl mb-4">🏖</div>
           <h4 className="font-bold text-orange-900 mb-2">Quick Holiday Label</h4>
           <p className="text-xs text-orange-800 mb-6 leading-relaxed">Instantly notify all students about a canteen holiday to avoid food wastage.</p>
           <button 
             onClick={markHoliday}
             className="bg-white text-orange-700 font-bold py-3 rounded-xl border border-orange-200 hover:bg-orange-100 transition-all shadow-sm"
           >
             Mark Holiday
           </button>
        </div>
      </div>

      <div className="space-y-4">
        <h3 className="font-bold text-slate-800">Sent Broadcasts</h3>
        {notices.map(notice => (
          <div key={notice.id} className="bg-white p-5 rounded-2xl border border-slate-100 flex justify-between items-start group hover:shadow-md transition-all">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <h4 className="font-bold text-slate-800">{notice.title}</h4>
                {notice.isImportant && <span className="bg-red-100 text-red-600 text-[10px] font-bold px-2 py-0.5 rounded uppercase">Urgent</span>}
              </div>
              <p className="text-slate-500 text-sm">{notice.content}</p>
              <p className="text-[10px] text-slate-300 font-mono mt-2 uppercase">{notice.date}</p>
            </div>
            <button 
              onClick={() => removeNotice(notice.id)}
              className="text-slate-200 hover:text-red-500 p-2"
            >
              🗑️
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default NoticeManager;
