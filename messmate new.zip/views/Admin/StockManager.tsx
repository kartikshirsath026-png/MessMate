import React, { useState, useEffect } from 'react';
import { GroceryItem } from '../../types';
import { geminiService } from '../../services/geminiService';

interface StockManagerProps {
  groceries: GroceryItem[];
  setGroceries: React.Dispatch<React.SetStateAction<GroceryItem[]>>;
}

const StockManager: React.FC<StockManagerProps> = ({ groceries, setGroceries }) => {
  const [isPredicting, setIsPredicting] = useState(false);
  const [predictions, setPredictions] = useState<any[]>([]);
  const [newItem, setNewItem] = useState({ name: '', quantity: 0, unit: 'kg', minLimit: 0 });

  const handleAddItem = () => {
    if (!newItem.name) return;
    const item: GroceryItem = {
      id: Math.random().toString(36).substr(2, 9),
      ...newItem,
      lastRestocked: new Date().toISOString().split('T')[0]
    };
    setGroceries([...groceries, item]);
    setNewItem({ name: '', quantity: 0, unit: 'kg', minLimit: 0 });
  };

  const handleUpdateQuantity = (id: string, delta: number) => {
    setGroceries(prev => prev.map(item => 
      item.id === id ? { ...item, quantity: Math.max(0, item.quantity + delta) } : item
    ));
  };

  const runPrediction = async () => {
    setIsPredicting(true);
    const results = await geminiService.predictStockDuration(groceries);
    setPredictions(results);
    setIsPredicting(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Grocery Stock Management</h2>
        <button 
          onClick={runPrediction}
          disabled={isPredicting}
          className="bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-2 rounded-xl flex items-center gap-2 transition-all disabled:opacity-50"
        >
          {isPredicting ? 'Analyzing...' : '🤖 AI Stock Prediction'}
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-2 bg-slate-900/50 border border-slate-800 rounded-3xl p-6">
          <h3 className="text-lg font-semibold mb-4">Current Inventory</h3>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="text-left text-slate-500 text-sm border-b border-slate-800">
                  <th className="pb-3 px-2">Item</th>
                  <th className="pb-3 px-2">Quantity</th>
                  <th className="pb-3 px-2">Min Limit</th>
                  <th className="pb-3 px-2 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                {groceries.map(item => (
                  <tr key={item.id} className="group">
                    <td className="py-4 px-2">
                      <div className="font-medium">{item.name}</div>
                      <div className="text-xs text-slate-500">Last restocked: {item.lastRestocked}</div>
                    </td>
                    <td className="py-4 px-2">
                      <div className={`flex items-center gap-2 ${item.quantity <= item.minLimit ? 'text-red-400' : 'text-slate-200'}`}>
                        <span className="font-mono font-bold">{item.quantity}</span>
                        <span className="text-xs opacity-60">{item.unit}</span>
                        {item.quantity <= item.minLimit && <span className="text-[10px] bg-red-500/20 px-1.5 py-0.5 rounded uppercase font-bold">Low</span>}
                      </div>
                    </td>
                    <td className="py-4 px-2 text-slate-400 text-sm">{item.minLimit} {item.unit}</td>
                    <td className="py-4 px-2 text-right">
                      <div className="flex justify-end gap-1">
                        <button onClick={() => handleUpdateQuantity(item.id, -1)} className="p-1 hover:bg-slate-800 rounded">-</button>
                        <button onClick={() => handleUpdateQuantity(item.id, 1)} className="p-1 hover:bg-slate-800 rounded">+</button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="space-y-6">
          <div className="bg-slate-900/50 border border-slate-800 rounded-3xl p-6">
            <h3 className="text-lg font-semibold mb-4">Add New Item</h3>
            <div className="space-y-4">
              <div>
                <label className="text-xs text-slate-500 uppercase font-bold mb-1 block">Item Name</label>
                <input 
                  type="text" 
                  value={newItem.name}
                  onChange={e => setNewItem({...newItem, name: e.target.value})}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2 focus:ring-2 focus:ring-orange-500 outline-none"
                  placeholder="e.g. Rice"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-xs text-slate-500 uppercase font-bold mb-1 block">Initial Qty</label>
                  <input 
                    type="number" 
                    value={newItem.quantity}
                    onChange={e => setNewItem({...newItem, quantity: Number(e.target.value)})}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2 focus:ring-2 focus:ring-orange-500 outline-none"
                  />
                </div>
                <div>
                  <label className="text-xs text-slate-500 uppercase font-bold mb-1 block">Unit</label>
                  <select 
                    value={newItem.unit}
                    onChange={e => setNewItem({...newItem, unit: e.target.value})}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2 focus:ring-2 focus:ring-orange-500 outline-none"
                  >
                    <option value="kg">kg</option>
                    <option value="liter">liter</option>
                    <option value="pcs">pcs</option>
                    <option value="bag">bag</option>
                  </select>
                </div>
              </div>
              <div>
                <label className="text-xs text-slate-500 uppercase font-bold mb-1 block">Min Limit (Alert)</label>
                <input 
                  type="number" 
                  value={newItem.minLimit}
                  onChange={e => setNewItem({...newItem, minLimit: Number(e.target.value)})}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2 focus:ring-2 focus:ring-orange-500 outline-none"
                />
              </div>
              <button 
                onClick={handleAddItem}
                className="w-full bg-orange-600 hover:bg-orange-700 text-white font-bold py-3 rounded-xl transition-all"
              >
                Add to Stock
              </button>
            </div>
          </div>

          {predictions.length > 0 && (
            <div className="bg-emerald-900/20 border border-emerald-800/30 rounded-3xl p-6">
              <h3 className="text-emerald-400 font-bold mb-4 flex items-center gap-2">
                <span>🤖</span> AI Stock Predictions
              </h3>
              <div className="space-y-3">
                {predictions.map((p, i) => (
                  <div key={i} className="flex justify-between items-center text-sm">
                    <span className="text-slate-300">{p.itemName}</span>
                    <div className="flex items-center gap-2">
                      <span className={`font-mono ${p.alert ? 'text-red-400' : 'text-emerald-400'}`}>
                        {p.daysRemaining} days
                      </span>
                      {p.alert && <span className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></span>}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default StockManager;
