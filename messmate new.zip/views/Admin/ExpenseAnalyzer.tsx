import React, { useState, useEffect } from 'react';
import { ExpenseRecord, Student, SubscriptionPlan } from '../../types';
import { geminiService } from '../../services/geminiService';
import { SUBSCRIPTION_PRANS_INFO } from '../../constants';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell, PieChart, Pie } from 'recharts';

interface ExpenseAnalyzerProps {
  expenses: ExpenseRecord[];
  setExpenses: React.Dispatch<React.SetStateAction<ExpenseRecord[]>>;
  students: Student[];
}

const ExpenseAnalyzer: React.FC<ExpenseAnalyzerProps> = ({ expenses, setExpenses, students }) => {
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysis, setAnalysis] = useState<any>(null);
  const [newExpense, setNewExpense] = useState({ category: 'GROCERY' as any, amount: 0, description: '' });

  const totalIncome = students.reduce((acc, s) => {
    if (s.subscriptionPlan) {
      return acc + (SUBSCRIPTION_PRANS_INFO[s.subscriptionPlan]?.price || 0);
    }
    return acc;
  }, 0);

  const totalExpenses = expenses.reduce((acc, e) => acc + e.amount, 0);
  const netProfit = totalIncome - totalExpenses;

  const handleAddExpense = () => {
    if (newExpense.amount <= 0) return;
    const expense: ExpenseRecord = {
      id: Math.random().toString(36).substr(2, 9),
      ...newExpense,
      date: new Date().toISOString().split('T')[0]
    };
    setExpenses([...expenses, expense]);
    setNewExpense({ category: 'GROCERY', amount: 0, description: '' });
  };

  const runAnalysis = async () => {
    setIsAnalyzing(true);
    const result = await geminiService.analyzeFinancials(totalIncome, expenses);
    setAnalysis(result);
    setIsAnalyzing(false);
  };

  const chartData = [
    { name: 'Income', value: totalIncome, fill: '#10b981' },
    { name: 'Expenses', value: totalExpenses, fill: '#ef4444' }
  ];

  const categoryData = Object.entries(
    expenses.reduce((acc, e) => {
      acc[e.category] = (acc[e.category] || 0) + e.amount;
      return acc;
    }, {} as Record<string, number>)
  ).map(([name, value]) => ({ name, value }));

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Expense & Profit Analyzer</h2>
        <button 
          onClick={runAnalysis}
          disabled={isAnalyzing}
          className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-xl flex items-center gap-2 transition-all disabled:opacity-50"
        >
          {isAnalyzing ? 'Analyzing...' : '🤖 AI Financial Insights'}
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-slate-900/50 border border-slate-800 p-6 rounded-3xl">
          <p className="text-slate-500 text-xs uppercase font-bold mb-1">Total Income</p>
          <p className="text-2xl font-mono font-bold text-emerald-500">₹{totalIncome.toLocaleString()}</p>
        </div>
        <div className="bg-slate-900/50 border border-slate-800 p-6 rounded-3xl">
          <p className="text-slate-500 text-xs uppercase font-bold mb-1">Total Expenses</p>
          <p className="text-2xl font-mono font-bold text-red-500">₹{totalExpenses.toLocaleString()}</p>
        </div>
        <div className="bg-slate-900/50 border border-slate-800 p-6 rounded-3xl">
          <p className="text-slate-500 text-xs uppercase font-bold mb-1">Net Profit</p>
          <p className={`text-2xl font-mono font-bold ${netProfit >= 0 ? 'text-emerald-500' : 'text-red-500'}`}>
            ₹{netProfit.toLocaleString()}
          </p>
        </div>
        <div className="bg-slate-900/50 border border-slate-800 p-6 rounded-3xl">
          <p className="text-slate-500 text-xs uppercase font-bold mb-1">Profit Margin</p>
          <p className="text-2xl font-mono font-bold text-slate-200">
            {totalIncome > 0 ? ((netProfit / totalIncome) * 100).toFixed(1) : 0}%
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-2 bg-slate-900/50 border border-slate-800 rounded-3xl p-6">
          <h3 className="text-lg font-semibold mb-6">Financial Overview</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
                <XAxis dataKey="name" stroke="#64748b" fontSize={12} />
                <YAxis stroke="#64748b" fontSize={12} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#0f172a', border: '1px solid #1e293b', borderRadius: '12px' }}
                  itemStyle={{ color: '#f8fafc' }}
                />
                <Bar dataKey="value" radius={[8, 8, 0, 0]}>
                  {chartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.fill} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-slate-900/50 border border-slate-800 rounded-3xl p-6">
          <h3 className="text-lg font-semibold mb-4">Add Expense</h3>
          <div className="space-y-4">
            <div>
              <label className="text-xs text-slate-500 uppercase font-bold mb-1 block">Category</label>
              <select 
                value={newExpense.category}
                onChange={e => setNewExpense({...newExpense, category: e.target.value as any})}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2 focus:ring-2 focus:ring-indigo-500 outline-none"
              >
                <option value="GROCERY">Grocery</option>
                <option value="ELECTRICITY">Electricity</option>
                <option value="GAS">Gas</option>
                <option value="SALARY">Salary</option>
                <option value="OTHER">Other</option>
              </select>
            </div>
            <div>
              <label className="text-xs text-slate-500 uppercase font-bold mb-1 block">Amount (₹)</label>
              <input 
                type="number" 
                value={newExpense.amount}
                onChange={e => setNewExpense({...newExpense, amount: Number(e.target.value)})}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2 focus:ring-2 focus:ring-indigo-500 outline-none"
              />
            </div>
            <div>
              <label className="text-xs text-slate-500 uppercase font-bold mb-1 block">Description</label>
              <input 
                type="text" 
                value={newExpense.description}
                onChange={e => setNewExpense({...newExpense, description: e.target.value})}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2 focus:ring-2 focus:ring-indigo-500 outline-none"
                placeholder="e.g. Monthly vegetables"
              />
            </div>
            <button 
              onClick={handleAddExpense}
              className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3 rounded-xl transition-all"
            >
              Record Expense
            </button>
          </div>
        </div>
      </div>

      {analysis && (
        <div className="bg-indigo-900/20 border border-indigo-800/30 rounded-3xl p-6">
          <h3 className="text-indigo-400 font-bold mb-4 flex items-center gap-2">
            <span>🤖</span> AI Financial Analysis
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <p className="text-slate-300 mb-4">{analysis.status}</p>
              <div className="space-y-2">
                {analysis.suggestions.map((s: string, i: number) => (
                  <div key={i} className="flex gap-2 text-sm text-slate-400">
                    <span className="text-indigo-500">•</span>
                    <span>{s}</span>
                  </div>
                ))}
              </div>
            </div>
            <div className="h-48">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={categoryData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={80}
                    paddingAngle={5}
                    dataKey="value"
                  >
                    {categoryData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={['#6366f1', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6'][index % 5]} />
                    ))}
                  </Pie>
                  <Tooltip 
                    contentStyle={{ backgroundColor: '#0f172a', border: '1px solid #1e293b', borderRadius: '12px' }}
                    itemStyle={{ color: '#f8fafc' }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ExpenseAnalyzer;
