import React, { useState } from 'react';
import { Notice, Poll, Feedback, MenuItem, CanteenContact, HolidayApplication, Student } from '../../types';
import { geminiService } from '../../services/geminiService';
import { DBConfig } from '../../services/apiService';

interface AdminDashboardProps {
  stats: { total: number; unpaid: number };
  notices: Notice[];
  polls: Poll[];
  feedbacks: Feedback[];
  canteenStatus: 'OPEN' | 'CLOSED' | 'BUSY';
  setCanteenStatus: (status: 'OPEN' | 'CLOSED' | 'BUSY') => void;
  adminConfig: {
    username: string;
    setUsername: (u: string) => void;
    password: string;
    setPassword: (p: string) => void;
    securityQuestion: string;
    setSecurityQuestion: (q: string) => void;
    securityAnswer: string;
    setSecurityAnswer: (a: string) => void;
  };
  contact: CanteenContact;
  setContact: (c: CanteenContact) => void;
  dbConfig: DBConfig;
  setDbConfig: (c: DBConfig) => void;
  holidays: HolidayApplication[];
  onHolidayAction: (id: string, action: 'APPROVE' | 'REJECT') => void;
  students: Student[];
}

const AdminDashboard: React.FC<AdminDashboardProps> = ({ stats, notices, polls, feedbacks, canteenStatus, setCanteenStatus, adminConfig, contact, setContact, dbConfig, setDbConfig, holidays, onHolidayAction, students }) => {
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [inventoryInput, setInventoryInput] = useState('');
  const [aiChefDish, setAiChefDish] = useState<any>(null);
  const [demandPrediction, setDemandPrediction] = useState<any>(null);
  const [isPredictingDemand, setIsPredictingDemand] = useState(false);

  const pendingHolidays = holidays.filter(h => h.status === 'PENDING');

  const handleAiChef = async () => {
    if (!inventoryInput) return;
    setIsAnalyzing(true);
    const dish = await geminiService.generateSmartMenu(inventoryInput);
    setAiChefDish(dish);
    setIsAnalyzing(false);
  };

  const handlePredictDemand = async () => {
    setIsPredictingDemand(true);
    // Use dummy attendance for prediction demo
    const dummyAttendance = students[0]?.attendance || [];
    const result = await geminiService.predictDemand(dummyAttendance, students.length);
    setDemandPrediction(result);
    setIsPredictingDemand(false);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setContact({ ...contact, qrCode: reader.result as string });
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="space-y-6 pb-12">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-slate-900 p-6 rounded-3xl border border-slate-800 shadow-xl">
          <p className="text-slate-500 text-[10px] font-bold uppercase tracking-widest">Total Students</p>
          <p className="text-3xl font-bold text-white mt-1">{stats.total}</p>
        </div>
        <div className="bg-orange-600 p-6 rounded-3xl shadow-xl shadow-orange-950/20 text-white border border-orange-500/20">
          <p className="text-orange-200 text-[10px] font-bold uppercase tracking-widest">Pending Holidays</p>
          <p className="text-3xl font-bold mt-1">{pendingHolidays.length}</p>
          <p className="text-[10px] mt-1 opacity-80">Requires approval</p>
        </div>
        <div className="bg-slate-900 p-6 rounded-3xl border border-slate-800 shadow-xl">
          <p className="text-slate-500 text-[10px] font-bold uppercase tracking-widest">Unpaid Balance</p>
          <p className="text-3xl font-bold text-red-500 mt-1">{stats.unpaid}</p>
        </div>
        <div className="bg-slate-900 p-6 rounded-3xl border border-slate-800 shadow-xl">
          <p className="text-slate-500 text-[10px] font-bold uppercase tracking-widest">Status</p>
          <p className={`text-xl font-bold mt-2 ${canteenStatus === 'OPEN' ? 'text-green-400' : 'text-amber-400'}`}>{canteenStatus}</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="space-y-6">
          {/* Holiday Approvals */}
          <div className="bg-slate-900 p-8 rounded-3xl border border-slate-800 shadow-xl">
            <h3 className="font-bold text-white mb-6 flex items-center gap-3">
              <span className="p-2 bg-orange-500/10 text-orange-400 rounded-2xl border border-orange-500/20">📅</span>
              Holiday Approvals
            </h3>
            {pendingHolidays.length === 0 ? (
              <p className="text-sm text-slate-500 italic">No pending holiday applications.</p>
            ) : (
              <div className="space-y-4">
                {pendingHolidays.map(h => {
                  const student = students.find(s => s.rollNo === h.studentRollNo);
                  return (
                    <div key={h.id} className="bg-slate-800/50 p-4 rounded-2xl border border-slate-700 flex justify-between items-center">
                      <div>
                        <p className="font-bold text-slate-200">{student?.name || h.studentRollNo}</p>
                        <p className="text-xs text-slate-400">{h.startDate} to {h.endDate}</p>
                        <p className="text-[10px] text-slate-500 mt-1 italic">"{h.reason}"</p>
                      </div>
                      <div className="flex gap-2">
                        <button 
                          onClick={() => onHolidayAction(h.id, 'REJECT')}
                          className="p-2 bg-red-500/10 text-red-500 rounded-xl border border-red-500/20 hover:bg-red-500/20 transition-all"
                        >
                          ✕
                        </button>
                        <button 
                          onClick={() => onHolidayAction(h.id, 'APPROVE')}
                          className="p-2 bg-emerald-500/10 text-emerald-500 rounded-xl border border-emerald-500/20 hover:bg-emerald-500/20 transition-all"
                        >
                          ✓
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Admin Profile Settings */}
          <div className="bg-slate-900 p-8 rounded-3xl border border-slate-800 shadow-xl">
            <h3 className="font-bold text-white mb-6 flex items-center gap-3">
              <span className="p-2 bg-indigo-500/10 text-indigo-400 rounded-2xl border border-indigo-500/20">👤</span>
              Admin Profile Settings
            </h3>
            <div className="grid grid-cols-2 gap-4 mb-4">
              <div>
                <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1.5 ml-1">Username</label>
                <input 
                  className="w-full bg-slate-800 px-4 py-2.5 border border-slate-700 rounded-xl text-sm outline-none focus:ring-2 focus:ring-indigo-500 text-white"
                  value={adminConfig.username}
                  onChange={e => adminConfig.setUsername(e.target.value)}
                />
              </div>
              <div>
                <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1.5 ml-1">Password</label>
                <input 
                  type="password"
                  className="w-full bg-slate-800 px-4 py-2.5 border border-slate-700 rounded-xl text-sm outline-none focus:ring-2 focus:ring-indigo-500 text-white"
                  value={adminConfig.password}
                  onChange={e => adminConfig.setPassword(e.target.value)}
                />
              </div>
            </div>
            <div className="space-y-4">
              <div>
                <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1.5 ml-1">Recovery Question</label>
                <input 
                  className="w-full bg-slate-800 px-4 py-2.5 border border-slate-700 rounded-xl text-xs outline-none focus:ring-2 focus:ring-indigo-500 text-slate-300"
                  value={adminConfig.securityQuestion}
                  onChange={e => adminConfig.setSecurityQuestion(e.target.value)}
                />
              </div>
              <div>
                <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1.5 ml-1">Recovery Answer</label>
                <input 
                  className="w-full bg-slate-800 px-4 py-2.5 border border-slate-700 rounded-xl text-xs outline-none focus:ring-2 focus:ring-indigo-500 text-slate-300"
                  value={adminConfig.securityAnswer}
                  onChange={e => adminConfig.setSecurityAnswer(e.target.value)}
                />
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-6">
          {/* AI Demand Prediction */}
          <div className="bg-slate-900 p-8 rounded-3xl border border-slate-800 shadow-xl">
            <div className="flex justify-between items-center mb-6">
              <h3 className="font-bold text-white flex items-center gap-3">
                <span className="p-2 bg-emerald-500/10 text-emerald-400 rounded-2xl border border-emerald-500/20">📈</span>
                AI Demand Prediction
              </h3>
              <button 
                onClick={handlePredictDemand}
                disabled={isPredictingDemand}
                className="text-[10px] font-bold bg-emerald-600 text-white px-3 py-1.5 rounded-lg hover:bg-emerald-700 disabled:opacity-50"
              >
                {isPredictingDemand ? '...' : 'Predict'}
              </button>
            </div>
            {demandPrediction ? (
              <div className="space-y-4 animate-in fade-in slide-in-from-bottom-2">
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-slate-800/50 p-4 rounded-2xl border border-slate-700">
                    <p className="text-[10px] text-slate-500 uppercase font-bold">Predicted Attendance</p>
                    <p className="text-2xl font-bold text-emerald-400">{demandPrediction.predictedAttendance}</p>
                  </div>
                  <div className="bg-slate-800/50 p-4 rounded-2xl border border-slate-700">
                    <p className="text-[10px] text-slate-500 uppercase font-bold">Rice Needed</p>
                    <p className="text-2xl font-bold text-slate-200">{demandPrediction.riceKg}kg</p>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-slate-800/50 p-4 rounded-2xl border border-slate-700">
                    <p className="text-[10px] text-slate-500 uppercase font-bold">Chapatis</p>
                    <p className="text-2xl font-bold text-slate-200">{demandPrediction.chapatiPcs}</p>
                  </div>
                  <div className="bg-slate-800/50 p-4 rounded-2xl border border-slate-700">
                    <p className="text-[10px] text-slate-500 uppercase font-bold">Vegetables</p>
                    <p className="text-2xl font-bold text-slate-200">{demandPrediction.vegKg}kg</p>
                  </div>
                </div>
                <p className="text-[10px] text-slate-500 italic leading-relaxed">{demandPrediction.reasoning}</p>
              </div>
            ) : (
              <p className="text-xs text-slate-400">Click predict to analyze attendance trends and food requirements.</p>
            )}
          </div>

          <div className="bg-slate-900 p-8 rounded-3xl border border-slate-800 shadow-xl h-fit">
            <h3 className="font-bold text-white mb-6 flex items-center gap-3">
              <span className="p-2 bg-emerald-500/10 text-emerald-400 rounded-2xl border border-emerald-500/20">💰</span>
              Canteen & Fee Settings
            </h3>
            <div className="space-y-5">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1.5 ml-1">Owner Name</label>
                  <input 
                    className="w-full bg-slate-800 px-4 py-2.5 border border-slate-700 rounded-xl text-sm outline-none focus:ring-2 focus:ring-emerald-500 text-white"
                    value={contact.ownerName}
                    onChange={e => setContact({...contact, ownerName: e.target.value})}
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1.5 ml-1">Monthly Fee (₹)</label>
                  <input 
                    type="number"
                    className="w-full bg-slate-800 px-4 py-2.5 border border-slate-700 rounded-xl text-sm outline-none focus:ring-2 focus:ring-emerald-500 text-orange-400 font-bold"
                    value={contact.membershipFee}
                    onChange={e => setContact({...contact, membershipFee: parseInt(e.target.value) || 0})}
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1.5 ml-1">Contact No.</label>
                  <input 
                    className="w-full bg-slate-800 px-4 py-2.5 border border-slate-700 rounded-xl text-sm outline-none focus:ring-2 focus:ring-emerald-500 text-white"
                    value={contact.phone}
                    onChange={e => setContact({...contact, phone: e.target.value})}
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1.5 ml-1">UPI ID</label>
                  <input 
                    className="w-full bg-slate-800 px-4 py-2.5 border border-slate-700 rounded-xl text-sm outline-none focus:ring-2 focus:ring-emerald-500 text-white font-mono"
                    value={contact.upiId}
                    onChange={e => setContact({...contact, upiId: e.target.value})}
                  />
                </div>
              </div>
              <div>
                <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-2 ml-1">QR Code Upload</label>
                <div className="flex items-center gap-6 p-4 bg-slate-800/50 rounded-2xl border border-slate-800">
                  <div className="w-16 h-16 bg-slate-800 rounded-xl border border-slate-700 flex items-center justify-center overflow-hidden shrink-0">
                    {contact.qrCode ? (
                      <img src={contact.qrCode} alt="QR Preview" className="w-full h-full object-cover" />
                    ) : (
                      <span className="text-xl">📷</span>
                    )}
                  </div>
                  <input 
                    type="file"
                    accept="image/*"
                    onChange={handleFileChange}
                    className="text-xs text-slate-400 file:mr-4 file:py-2 file:px-4 file:rounded-xl file:border-0 file:text-[10px] file:font-bold file:bg-emerald-600 file:text-white hover:file:bg-emerald-700 cursor-pointer"
                  />
                </div>
              </div>
            </div>
          </div>

          <div className="bg-slate-900 p-8 rounded-3xl border border-slate-800 shadow-xl h-fit">
            <h3 className="font-bold text-white mb-6 flex items-center gap-3">
              <span className="p-2 bg-orange-500/10 text-orange-400 rounded-2xl border border-orange-500/20">📡</span>
              Live Controls
            </h3>
            <div className="space-y-4">
               <div className="p-5 bg-slate-800/50 rounded-2xl border border-slate-800">
                 <span className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-4 block">Crowd Level Announcement</span>
                 <div className="grid grid-cols-3 gap-3">
                   {['OPEN', 'BUSY', 'CLOSED'].map(s => (
                     <button 
                       key={s}
                       onClick={() => setCanteenStatus(s as any)}
                       className={`py-3 rounded-xl text-xs font-bold transition-all border ${
                         canteenStatus === s 
                         ? 'bg-orange-600 border-orange-500 text-white shadow-lg shadow-orange-950/20' 
                         : 'bg-slate-800 border-slate-700 text-slate-500 hover:text-slate-300'
                       }`}
                     >
                       {s}
                     </button>
                   ))}
                 </div>
               </div>
               <p className="text-[10px] text-slate-500 text-center italic mt-4">Settings reflect instantly on student dashboards.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
