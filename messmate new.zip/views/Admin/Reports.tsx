
import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { Student, Feedback } from '../../types';

interface ReportsProps {
  students: Student[];
  feedbacks: Feedback[];
  fee: number;
}

const Reports: React.FC<ReportsProps> = ({ students, feedbacks, fee }) => {
  const activeCount = students.filter(s => s.membershipActive).length;
  const inactiveCount = students.length - activeCount;

  const membershipData = [
    { name: 'Active', value: activeCount },
    { name: 'Inactive', value: inactiveCount },
  ];

  const ratingCounts = [0, 0, 0, 0, 0];
  feedbacks.forEach(f => {
    if (f.rating >= 1 && f.rating <= 5) ratingCounts[f.rating - 1]++;
  });

  const ratingData = ratingCounts.map((count, i) => ({
    name: `${i + 1} Star`,
    count: count
  }));

  const COLORS = ['#10b981', '#ef4444'];

  return (
    <div className="space-y-8 pb-12">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-100">
          <h3 className="font-bold text-slate-800 mb-6">Membership Overview</h3>
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={membershipData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {membershipData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="flex justify-center gap-8 mt-4 text-sm font-medium">
            <div className="flex items-center gap-2"><span className="w-3 h-3 bg-green-500 rounded-full"></span> Active: {activeCount}</div>
            <div className="flex items-center gap-2"><span className="w-3 h-3 bg-red-500 rounded-full"></span> Inactive: {inactiveCount}</div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-100">
          <h3 className="font-bold text-slate-800 mb-6">Student Satisfaction (Ratings)</h3>
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={ratingData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="count" fill="#f97316" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-100">
        <h3 className="font-bold text-slate-800 mb-6">Financial Summary (Current Month)</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-center">
          <div className="p-6 bg-slate-50 rounded-2xl">
             <p className="text-slate-500 text-sm">Expected Collection</p>
             <p className="text-2xl font-bold text-slate-800 mt-1">₹ {students.length * fee}</p>
          </div>
          <div className="p-6 bg-green-50 rounded-2xl">
             <p className="text-green-600 text-sm">Collected (Paid Members)</p>
             <p className="text-2xl font-bold text-green-700 mt-1">₹ {activeCount * fee}</p>
          </div>
          <div className="p-6 bg-red-50 rounded-2xl">
             <p className="text-red-600 text-sm">Pending Amount</p>
             <p className="text-2xl font-bold text-red-700 mt-1">₹ {inactiveCount * fee}</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Reports;
