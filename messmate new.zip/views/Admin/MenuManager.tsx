
import React, { useState } from 'react';
import { MenuItem } from '../../types';
import { geminiService } from '../../services/geminiService';

interface MenuManagerProps {
  menu: MenuItem[];
  setMenu: (m: MenuItem[]) => void;
}

const MenuManager: React.FC<MenuManagerProps> = ({ menu, setMenu }) => {
  const [showAdd, setShowAdd] = useState(false);
  const [newItem, setNewItem] = useState<Partial<MenuItem>>({ 
    type: 'Lunch', 
    isVegetarian: true,
    name: '',
    description: ''
  });
  const [analyzingId, setAnalyzingId] = useState<string | null>(null);

  const toggleFlashSale = (id: string) => {
    setMenu(menu.map(item => {
      if (item.id === id) {
        const isCurrentlyOnSale = !!item.isFlashSale;
        if (!isCurrentlyOnSale) {
          const price = prompt("Enter Flash Sale Price (₹):", "20");
          return { ...item, isFlashSale: true, salePrice: parseInt(price || "20") };
        }
        return { ...item, isFlashSale: false };
      }
      return item;
    }));
  };

  const handleAdd = () => {
    if (!newItem.name) {
      alert("Please enter a dish name.");
      return;
    }
    const item: MenuItem = {
      id: Date.now().toString(),
      name: newItem.name,
      type: (newItem.type as any) || 'Lunch',
      description: newItem.description || '',
      isVegetarian: !!newItem.isVegetarian
    };
    setMenu([...menu, item]);
    setNewItem({ type: 'Lunch', isVegetarian: true, name: '', description: '' });
    setShowAdd(false);
  };

  const removeDish = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    if (window.confirm("Remove this dish?")) {
      setMenu(menu.filter(i => i.id !== id));
    }
  };

  const analyzeNutrition = async (e: React.MouseEvent, id: string, name: string, desc?: string) => {
    e.stopPropagation();
    setAnalyzingId(id);
    try {
      const data = await geminiService.analyzeNutrition(name, desc || '');
      if (data) {
        setMenu(menu.map(item => 
          item.id === id ? { ...item, nutrition: data } : item
        ));
      }
    } catch (e) {
      alert("Nutrition analysis failed.");
    } finally {
      setAnalyzingId(null);
    }
  };

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center bg-slate-900 p-6 rounded-3xl border border-slate-800">
        <div>
          <h2 className="text-xl font-bold text-white">Culinary Command Center</h2>
          <p className="text-sm text-slate-500">Manage daily dishes and trigger surplus sales.</p>
        </div>
        <button 
          onClick={() => setShowAdd(!showAdd)} 
          className="bg-orange-600 text-white px-8 py-3 rounded-2xl text-sm font-black hover:bg-orange-700 shadow-xl shadow-orange-950/20 transition-all"
        >
          {showAdd ? 'Cancel' : '+ New Dish'}
        </button>
      </div>

      {showAdd && (
        <div className="bg-slate-900 p-8 rounded-[32px] border border-slate-800 shadow-2xl space-y-6 animate-in slide-in-from-top-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1">Dish Name</label>
              <input 
                placeholder="Butter Chicken / Paneer Tikka" 
                className="w-full bg-slate-800 px-5 py-4 border border-slate-700 rounded-2xl outline-none focus:ring-2 focus:ring-orange-500 text-white" 
                value={newItem.name}
                onChange={e => setNewItem({...newItem, name: e.target.value})} 
              />
            </div>
            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1">Category</label>
              <select 
                className="w-full bg-slate-800 px-5 py-4 border border-slate-700 rounded-2xl outline-none focus:ring-2 focus:ring-orange-500 text-white"
                value={newItem.type}
                onChange={e => setNewItem({...newItem, type: e.target.value as any})}
              >
                <option value="Breakfast">Breakfast</option>
                <option value="Lunch">Lunch</option>
                <option value="Snack">Snack</option>
                <option value="Dinner">Dinner</option>
              </select>
            </div>
          </div>
          <button onClick={handleAdd} className="w-full bg-white text-black font-black py-4 rounded-2xl hover:bg-slate-200 transition-all">Publish to Menu</button>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {menu.map(item => (
          <div key={item.id} className={`bg-slate-900 p-6 rounded-[32px] border transition-all group relative ${item.isFlashSale ? 'border-red-500/50 ring-2 ring-red-500/10' : 'border-slate-800 hover:border-slate-700'}`}>
            <div className="absolute top-4 right-4 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
              <button 
                onClick={() => toggleFlashSale(item.id)}
                className={`p-2 rounded-xl border transition-all ${item.isFlashSale ? 'bg-red-600 text-white border-red-500' : 'bg-slate-800 text-red-500 border-slate-700 hover:bg-red-500/10'}`}
                title="Trigger Flash Sale"
              >
                ⚡
              </button>
              <button onClick={(e) => removeDish(e, item.id)} className="p-2 bg-slate-800 text-slate-400 border border-slate-700 rounded-xl hover:text-white">🗑️</button>
            </div>
            
            <div className="flex items-center gap-2 mb-4">
              <span className="bg-slate-800 text-slate-400 px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest">{item.type}</span>
              {item.isFlashSale && <span className="bg-red-600 text-white px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest animate-pulse">Flash Sale: ₹{item.salePrice}</span>}
            </div>

            <h3 className="font-black text-white text-xl mb-2">{item.name}</h3>
            
            <div className="flex justify-between items-center mt-6 pt-6 border-t border-slate-800">
               <button 
                 onClick={(e) => analyzeNutrition(e, item.id, item.name, item.description)}
                 className="text-[10px] font-black text-indigo-400 uppercase tracking-widest hover:text-indigo-300"
               >
                 {analyzingId === item.id ? 'Analyzing...' : '✨ View Nutrition'}
               </button>
               {item.nutrition && (
                 <div className="flex gap-2">
                   <span className="text-[10px] font-bold text-orange-400">🔥 {item.nutrition.calories}</span>
                   <span className="text-[10px] font-bold text-emerald-400">🥩 {item.nutrition.protein}g</span>
                 </div>
               )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default MenuManager;
