import React, { useState } from 'react';
import { Student } from '../../types';

interface StudentManagerProps {
  students: Student[];
  setStudents: (s: Student[]) => void;
}

const StudentManager: React.FC<StudentManagerProps> = ({ students, setStudents }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);
  const [newStudent, setNewStudent] = useState({ rollNo: '', name: '', hostel: 'H-1' });

  const toggleMembership = (rollNo: string) => {
    setStudents(students.map(s => 
      s.rollNo === rollNo ? { ...s, membershipActive: !s.membershipActive } : s
    ));
  };

  const removeStudent = (rollNo: string) => {
    if (confirm(`Are you sure you want to remove student ${rollNo}? All their history will be deleted.`)) {
      setStudents(students.filter(s => s.rollNo !== rollNo));
    }
  };

  const handleAddStudent = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newStudent.rollNo || !newStudent.name) return;
    
    if (students.some(s => s.rollNo === newStudent.rollNo)) {
      alert("Student with this Roll No already exists!");
      return;
    }

    // Fix: Adding the missing ecoCredits property required by the Student interface
    const student: Student = {
      ...newStudent,
      membershipActive: false,
      lastPaymentDate: 'N/A',
      payments: [],
      attendance: [],
      ecoCredits: 0
    };
    
    setStudents([...students, student]);
    setNewStudent({ rollNo: '', name: '', hostel: 'H-1' });
    setShowAddModal(false);
  };

  const calculateExpiryDate = (student: Student) => {
    if (!student.lastPaymentDate || student.lastPaymentDate === 'N/A') return 'N/A';
    const date = new Date(student.lastPaymentDate);
    const absentDays = (student.attendance || []).filter(a => a.status === 'ABSENT').length;
    date.setDate(date.getDate() + 30 + absentDays);
    return date.toLocaleDateString('en-IN', { day: 'numeric', month: 'short' });
  };

  const filtered = students.filter(s => 
    s.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    s.rollNo.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row gap-4 justify-between items-center">
        <div className="relative w-full md:w-96">
          <input 
            type="text" 
            placeholder="Search student by Roll No or Name..." 
            className="w-full pl-10 pr-4 py-2 border rounded-xl focus:ring-2 focus:ring-orange-500 outline-none text-slate-900"
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
          />
          <span className="absolute left-3 top-2.5 text-slate-400">🔍</span>
        </div>
        <button 
          onClick={() => setShowAddModal(true)}
          className="bg-orange-600 text-white px-6 py-2 rounded-xl text-sm font-semibold hover:bg-orange-700 w-full md:w-auto shadow-lg transition-all"
        >
          + Enroll New Student
        </button>
      </div>

      {showAddModal && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-8 w-full max-w-md shadow-2xl animate-in fade-in zoom-in duration-200">
            <h3 className="text-xl font-bold text-slate-800 mb-6">New Student Enrollment</h3>
            <form onSubmit={handleAddStudent} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase mb-1">Roll Number</label>
                <input 
                  autoFocus
                  required
                  placeholder="e.g. 2024CS01"
                  className="w-full px-4 py-2 border rounded-xl outline-none focus:ring-2 focus:ring-orange-500 text-slate-900"
                  value={newStudent.rollNo}
                  onChange={e => setNewStudent({...newStudent, rollNo: e.target.value.toUpperCase()})}
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase mb-1">Full Name</label>
                <input 
                  required
                  placeholder="Student Name"
                  className="w-full px-4 py-2 border rounded-xl outline-none focus:ring-2 focus:ring-orange-500 text-slate-900"
                  value={newStudent.name}
                  onChange={e => setNewStudent({...newStudent, name: e.target.value})}
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase mb-1">Hostel Block</label>
                <select 
                  className="w-full px-4 py-2 border rounded-xl outline-none focus:ring-2 focus:ring-orange-500 text-slate-900"
                  value={newStudent.hostel}
                  onChange={e => setNewStudent({...newStudent, hostel: e.target.value})}
                >
                  <option>H-1</option>
                  <option>H-2</option>
                  <option>H-3</option>
                  <option>G-1</option>
                  <option>G-2</option>
                </select>
              </div>
              <div className="flex gap-3 pt-4">
                <button 
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="flex-1 py-2 text-slate-500 font-semibold hover:bg-slate-50 rounded-xl"
                >
                  Cancel
                </button>
                <button 
                  type="submit"
                  className="flex-1 py-2 bg-slate-900 text-white font-semibold rounded-xl hover:bg-slate-800"
                >
                  Register
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-x-auto">
        <table className="w-full text-left border-collapse min-w-[800px]">
          <thead>
            <tr className="bg-slate-50 border-b border-slate-100">
              <th className="p-4 font-semibold text-slate-600 text-sm">Roll No</th>
              <th className="p-4 font-semibold text-slate-600 text-sm">Name</th>
              <th className="p-4 font-semibold text-slate-600 text-sm">Absent Days</th>
              <th className="p-4 font-semibold text-slate-600 text-sm text-center">Membership</th>
              <th className="p-4 font-semibold text-slate-600 text-sm">Valid Until</th>
              <th className="p-4 font-semibold text-slate-600 text-sm text-right">Actions</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map(student => {
              const absentCount = (student.attendance || []).filter(a => a.status === 'ABSENT').length;
              return (
                <tr key={student.rollNo} className="border-b border-slate-50 hover:bg-slate-50 transition-all group">
                  <td className="p-4 text-sm font-mono text-slate-600">{student.rollNo}</td>
                  <td className="p-4 text-sm font-medium text-slate-800">{student.name}</td>
                  <td className="p-4 text-sm">
                    <span className={`font-bold ${absentCount > 0 ? 'text-indigo-600' : 'text-slate-300'}`}>
                      {absentCount} Days
                    </span>
                  </td>
                  <td className="p-4 text-sm text-center">
                    <span className={`px-2 py-1 rounded-full text-[10px] font-bold ${student.membershipActive ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                      {student.membershipActive ? 'ACTIVE' : 'INACTIVE'}
                    </span>
                  </td>
                  <td className="p-4 text-sm text-slate-500">{calculateExpiryDate(student)}</td>
                  <td className="p-4 text-right flex justify-end gap-2">
                    <button 
                      onClick={() => toggleMembership(student.rollNo)}
                      className={`text-xs font-bold py-1.5 px-3 rounded-lg transition-all ${
                        student.membershipActive 
                        ? 'text-red-600 hover:bg-red-50' 
                        : 'text-green-600 hover:bg-green-50'
                      }`}
                      title={student.membershipActive ? 'Deactivate' : 'Activate'}
                    >
                      {student.membershipActive ? 'Revoke' : 'Verify'}
                    </button>
                    <button 
                      onClick={() => removeStudent(student.rollNo)}
                      className="text-slate-300 hover:text-red-500 p-2"
                    >
                      🗑️
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
        {filtered.length === 0 && (
          <div className="p-20 text-center">
             <p className="text-slate-400">No students found matching your search.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default StudentManager;