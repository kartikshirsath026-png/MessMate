
import React from 'react';
import { Feedback } from '../../types';

interface FeedbackListProps {
  feedbacks: Feedback[];
}

const FeedbackList: React.FC<FeedbackListProps> = ({ feedbacks }) => {
  return (
    <div className="space-y-6 max-w-4xl">
      <div className="flex justify-between items-center mb-4">
         <h2 className="text-lg font-bold text-slate-800">Recent Feedbacks</h2>
         <span className="bg-slate-100 px-3 py-1 rounded-full text-xs font-medium text-slate-600">
           Total: {feedbacks.length}
         </span>
      </div>

      <div className="grid grid-cols-1 gap-4">
        {feedbacks.length === 0 && (
          <div className="bg-white p-20 rounded-3xl text-center border border-dashed border-slate-200">
             <p className="text-slate-400">No feedback submitted yet.</p>
          </div>
        )}
        {feedbacks.map(f => (
          <div key={f.id} className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex flex-col md:flex-row gap-6">
            <div className="flex-1">
              <div className="flex justify-between items-start mb-2">
                 <h4 className="font-bold text-slate-800">{f.studentName} <span className="text-xs font-mono font-normal text-slate-400 ml-2">{f.studentRollNo}</span></h4>
                 <div className="flex gap-1">
                   {[...Array(5)].map((_, i) => (
                     <span key={i} className={i < f.rating ? 'text-orange-400' : 'text-slate-200'}>★</span>
                   ))}
                 </div>
              </div>
              <p className="text-slate-600 text-sm italic leading-relaxed">"{f.comment}"</p>
              <p className="text-[10px] text-slate-300 font-mono mt-4 uppercase">{f.date}</p>
            </div>
            <div className="shrink-0 flex items-center">
              <button className="text-xs text-orange-600 font-bold hover:underline px-4 py-2 bg-orange-50 rounded-lg">
                Mark as Resolved
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default FeedbackList;
