import { GoogleGenAI, Type } from "@google/genai";
import { Feedback, MenuItem, Student, GroceryItem, ExpenseRecord, AttendanceRecord } from "../types";

export class GeminiService {
  async analyzeFeedback(feedbacks: Feedback[]) {
    if (!feedbacks.length) return "No feedback to analyze.";
    const feedbackStr = feedbacks.map(f => `[${f.rating}/5] ${f.comment}`).join('\n');
    const prompt = `Analyze student feedback for a canteen and summarize sentiment and improvements. Be concise.\n${feedbackStr}`;

    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: prompt,
      });
      return response.text;
    } catch (error) { return "Unable to analyze."; }
  }

  async generateSmartMenu(inventory: string) {
    const prompt = `I am a canteen owner. I have these surplus ingredients: "${inventory}". 
    Suggest one popular Indian canteen dish I can make to use these up.`;

    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              name: { type: Type.STRING },
              description: { type: Type.STRING }
            },
            required: ["name", "description"]
          }
        }
      });
      return JSON.parse(response.text || "{}");
    } catch (error) { return null; }
  }

  async analyzeNutrition(menu: MenuItem[]) {
    const menuStr = menu.map(m => `${m.name}: ${m.description || ''}`).join(', ');
    const prompt = `Estimate total nutrition for this menu: "${menuStr}". Provide average per serving.`;
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              calories: { type: Type.NUMBER },
              protein: { type: Type.NUMBER },
              carbs: { type: Type.NUMBER },
              fats: { type: Type.NUMBER }
            },
            required: ["calories", "protein", "carbs", "fats"]
          }
        }
      });
      return JSON.parse(response.text || "{}");
    } catch (error) { return null; }
  }

  async predictDemand(attendance: AttendanceRecord[], totalStudents: number) {
    const attendanceStr = attendance.slice(-14).map(a => `${a.date}: ${a.status}`).join(', ');
    const prompt = `Based on the last 14 days of attendance: ${attendanceStr}, and a total of ${totalStudents} students, predict the expected attendance for tomorrow. Also suggest quantities for Rice (kg), Chapati (pcs), and Vegetables (kg) for a standard Indian meal.`;

    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              predictedAttendance: { type: Type.NUMBER },
              riceKg: { type: Type.NUMBER },
              chapatiPcs: { type: Type.NUMBER },
              vegKg: { type: Type.NUMBER },
              reasoning: { type: Type.STRING }
            },
            required: ["predictedAttendance", "riceKg", "chapatiPcs", "vegKg", "reasoning"]
          }
        }
      });
      return JSON.parse(response.text || "{}");
    } catch (error) { return null; }
  }

  async analyzeFinancials(income: number, expenses: ExpenseRecord[]) {
    const expenseStr = expenses.map(e => `${e.category}: ${e.amount}`).join('\n');
    const prompt = `Monthly Income: ₹${income}. Expenses:\n${expenseStr}\nAnalyze the profit/loss and provide 3 smart suggestions to increase profitability or reduce waste.`;

    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              totalExpenses: { type: Type.NUMBER },
              netProfit: { type: Type.NUMBER },
              status: { type: Type.STRING },
              suggestions: { type: Type.ARRAY, items: { type: Type.STRING } }
            },
            required: ["totalExpenses", "netProfit", "status", "suggestions"]
          }
        }
      });
      return JSON.parse(response.text || "{}");
    } catch (error) { return null; }
  }

  async predictStockDuration(stock: GroceryItem[]) {
    const stockStr = stock.map(s => `${s.name}: ${s.quantity}${s.unit}`).join(', ');
    const prompt = `Current stock: ${stockStr}. Based on a typical canteen serving 100 students daily, estimate how many days each item will last.`;

    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                itemName: { type: Type.STRING },
                daysRemaining: { type: Type.NUMBER },
                alert: { type: Type.BOOLEAN }
              },
              required: ["itemName", "daysRemaining", "alert"]
            }
          }
        }
      });
      return JSON.parse(response.text || "[]");
    } catch (error) { return []; }
  }

  async getChatbotResponse(query: string, student: Student, menu: MenuItem[]) {
    const menuStr = menu.map(m => `- ${m.name} (${m.type})`).join('\n');
    const prompt = `You are MessMate AI, a helpful assistant for a college canteen.
Student Info: Name: ${student.name}, Remaining Days: ${student.remainingDays}, Expiry: ${student.expiryDate}, Plan: ${student.subscriptionPlan}.
Today's Menu:
${menuStr}

Holiday Rules: Must apply at least 24 hours in advance. Approved holidays extend subscription.

User Query: "${query}"
Provide a concise and helpful response.`;

    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: prompt,
      });
      return response.text;
    } catch (error) { return "I'm sorry, I'm having trouble connecting right now."; }
  }

  async getDietaryAdvice(query: string, menu: MenuItem[]) {
    const menuStr = menu.map(m => `- ${m.name} (${m.type}): ${m.description || 'No description'}`).join('\n');
    const prompt = `You are a nutrition coach for a student canteen. 
User query: "${query}"
Today's Canteen Menu:
${menuStr}

Provide concise, personalized dietary advice or answers based on the menu above.`;

    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: prompt,
      });
      return response.text;
    } catch (error) { 
      return "I'm unable to provide dietary advice at the moment."; 
    }
  }
}

export const geminiService = new GeminiService();
