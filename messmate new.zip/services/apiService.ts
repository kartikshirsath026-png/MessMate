import { Student, MenuItem, Notice, Poll, Feedback } from "../types";

export interface DBConfig {
  baseUrl: string;
  apiKey?: string;
  isEnabled: boolean;
}

/**
 * Standard API Service for external database communication.
 * This implementation uses standard REST patterns compatible with most backends.
 */
class ApiService {
  private getHeaders(config: DBConfig) {
    return {
      'Content-Type': 'application/json',
      'Authorization': config.apiKey ? `Bearer ${config.apiKey}` : '',
    };
  }

  async fetchWithConfig<T>(path: string, config: DBConfig): Promise<T> {
    const res = await fetch(`${config.baseUrl}${path}`, {
      headers: this.getHeaders(config)
    });
    if (!res.ok) throw new Error(`API Error: ${res.statusText}`);
    return res.json();
  }

  async postWithConfig<T>(path: string, data: T, config: DBConfig): Promise<void> {
    const res = await fetch(`${config.baseUrl}${path}`, {
      method: 'POST',
      headers: this.getHeaders(config),
      body: JSON.stringify(data),
    });
    if (!res.ok) throw new Error(`API Sync Failed: ${res.statusText}`);
  }

  // Helper to check if the server is alive
  async healthCheck(config: DBConfig): Promise<boolean> {
    try {
      const res = await fetch(`${config.baseUrl}/health`, { 
        method: 'GET', 
        headers: this.getHeaders(config),
        signal: AbortSignal.timeout(5000) 
      });
      return res.ok;
    } catch {
      return false;
    }
  }
}

export const apiService = new ApiService();

/**
 * MOCK API FALLBACK: Used when cloud is disabled or unavailable.
 */
const MOCK_DELAY = 100;
export const mockApiService = {
  async get<T>(key: string, fallback: T): Promise<T> {
    await new Promise(r => setTimeout(r, MOCK_DELAY));
    const data = localStorage.getItem(key);
    return data ? JSON.parse(data) : fallback;
  },
  async post<T>(key: string, data: T): Promise<void> {
    localStorage.setItem(key, JSON.stringify(data));
  }
};