
import { Student, MenuItem, Notice, Poll, SubscriptionPlan, Language, GroceryItem, ExpenseRecord, HolidayApplication } from './types';

export const SUBSCRIPTION_PRANS_INFO = {
  [SubscriptionPlan.DAILY]: { name: 'Daily Thali', price: 70, meals: 1 },
  [SubscriptionPlan.MONTHLY_SINGLE]: { name: 'Monthly Single Meal', price: 1500, meals: 1 },
  [SubscriptionPlan.MONTHLY_DOUBLE]: { name: 'Monthly Double Meal', price: 2700, meals: 2 },
};

export const INITIAL_STUDENTS: Student[] = [
  {
    rollNo: 'S101',
    name: 'Rahul Sharma',
    hostel: 'Hostel A',
    password: 'password123',
    email: 'rahul@example.com',
    membershipActive: true,
    subscriptionPlan: SubscriptionPlan.MONTHLY_DOUBLE,
    remainingDays: 15,
    expiryDate: '2026-03-17',
    lastPaymentDate: '2026-02-15',
    payments: [],
    attendance: [],
    ecoCredits: 50,
    language: Language.ENGLISH
  }
];

export const INITIAL_MENU: MenuItem[] = [
  {
    id: 'm1',
    name: 'Paneer Butter Masala',
    type: 'Lunch',
    description: 'Rich and creamy paneer curry',
    isVegetarian: true,
    nutrition: { calories: 350, protein: 12, carbs: 15, fats: 25 }
  },
  {
    id: 'm2',
    name: 'Dal Tadka',
    type: 'Lunch',
    description: 'Yellow lentils with tempering',
    isVegetarian: true,
    nutrition: { calories: 180, protein: 8, carbs: 25, fats: 5 }
  }
];

export const INITIAL_NOTICES: Notice[] = [
  {
    id: 'n1',
    title: 'Holiday Notice',
    content: 'Apply for holidays at least 24 hours in advance to extend your subscription.',
    date: '2026-03-01',
    isImportant: true
  }
];

export const INITIAL_POLLS: Poll[] = [];

export const INITIAL_GROCERIES: GroceryItem[] = [
  { id: 'g1', name: 'Rice', quantity: 50, unit: 'kg', minLimit: 10, lastRestocked: '2026-02-20' },
  { id: 'g2', name: 'Wheat Flour', quantity: 30, unit: 'kg', minLimit: 5, lastRestocked: '2026-02-22' }
];

export const INITIAL_EXPENSES: ExpenseRecord[] = [];

export const INITIAL_HOLIDAYS: HolidayApplication[] = [];
