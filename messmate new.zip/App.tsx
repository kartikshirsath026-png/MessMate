import React, { useState, useEffect } from 'react';
import { UserRole, Student, MenuItem, Notice, Poll, Feedback, ViewState, CanteenContact, GroceryItem, ExpenseRecord, HolidayApplication, Language, SubscriptionPlan } from './types';
import { INITIAL_STUDENTS, INITIAL_MENU, INITIAL_NOTICES, INITIAL_POLLS, INITIAL_GROCERIES, INITIAL_EXPENSES, INITIAL_HOLIDAYS } from './constants';
import { mockApiService, apiService, DBConfig } from './services/apiService';
import Login from './components/Login';
import Sidebar from './components/Sidebar';
import StudentDashboard from './views/Student/StudentDashboard';
import AdminDashboard from './views/Admin/AdminDashboard';
import MenuManager from './views/Admin/MenuManager';
import StudentManager from './views/Admin/StudentManager';
import FeedbackList from './views/Admin/FeedbackList';
import Reports from './views/Admin/Reports';
import NoticeManager from './views/Admin/NoticeManager';
import PollManager from './views/Admin/PollManager';
import StudentMenu from './views/Student/StudentMenu';
import StudentPolls from './views/Student/StudentPolls';
import StudentPayments from './views/Student/StudentPayments';
import StudentFeedback from './views/Student/StudentFeedback';
import StockManager from './views/Admin/StockManager';
import ExpenseAnalyzer from './views/Admin/ExpenseAnalyzer';
import HolidayManager from './views/Student/HolidayManager';
import AIChatbot from './views/Student/AIChatbot';

const DEFAULT_CONTACT: CanteenContact = {
  phone: '9876543210',
  upiId: 'canteen@upi',
  ownerName: 'Canteen Manager',
  membershipFee: 3000,
};

const App: React.FC = () => {
  const [user, setUser] = useState<{ role: UserRole; data: Student | null } | null>(null);
  const [view, setView] = useState<ViewState>('DASHBOARD');
  const [isLoading, setIsLoading] = useState(true);
  const [isSyncing, setIsSyncing] = useState(false);
  const [dbStatus, setDbStatus] = useState<'LOCAL' | 'CLOUD' | 'ERROR'>('LOCAL');
  
  // Database Configuration
  const [dbConfig, setDbConfig] = useState<DBConfig>({
    baseUrl: '',
    apiKey: '',
    isEnabled: false
  });

  const [canteenStatus, setCanteenStatus] = useState<'OPEN' | 'CLOSED' | 'BUSY'>('OPEN');
  const [adminUsername, setAdminUsername] = useState<string>('');
  const [adminPassword, setAdminPassword] = useState<string>('2606');
  const [adminSecurityQuestion, setAdminSecurityQuestion] = useState<string>('');
  const [adminSecurityAnswer, setAdminSecurityAnswer] = useState<string>('');
  const [canteenContact, setCanteenContact] = useState<CanteenContact>(DEFAULT_CONTACT);
  
  const [students, setStudents] = useState<Student[]>([]);
  const [menu, setMenu] = useState<MenuItem[]>([]);
  const [notices, setNotices] = useState<Notice[]>([]);
  const [polls, setPolls] = useState<Poll[]>([]);
  const [feedbacks, setFeedbacks] = useState<Feedback[]>([]);
  const [groceries, setGroceries] = useState<GroceryItem[]>([]);
  const [expenses, setExpenses] = useState<ExpenseRecord[]>([]);
  const [holidays, setHolidays] = useState<HolidayApplication[]>([]);

  // Load configuration and data
  useEffect(() => {
    const initData = async () => {
      setIsLoading(true);
      try {
        // First load DB config from local storage
        const savedConfig = localStorage.getItem('mm_db_config');
        const currentConfig: DBConfig = savedConfig ? JSON.parse(savedConfig) : { baseUrl: '', apiKey: '', isEnabled: false };
        setDbConfig(currentConfig);

        let data: any[] = [];
        
        // Try Cloud if enabled
        if (currentConfig.isEnabled && currentConfig.baseUrl) {
          const isHealthy = await apiService.healthCheck(currentConfig);
          if (isHealthy) {
            setDbStatus('CLOUD');
            // In a real app, you'd fetch specific endpoints. Here we mock the bulk fetch for simplicity.
            // data = await apiService.fetchWithConfig('/bulk-data', currentConfig);
          } else {
            setDbStatus('ERROR');
          }
        }

        // Always load from local as baseline or fallback
        const [s, m, n, p, f, status, userNm, pass, sQ, sA, contact, g, e, h] = await Promise.all([
          mockApiService.get('mm_students', INITIAL_STUDENTS),
          mockApiService.get('mm_menu', INITIAL_MENU),
          mockApiService.get('mm_notices', INITIAL_NOTICES),
          mockApiService.get('mm_polls', INITIAL_POLLS),
          mockApiService.get('mm_feedbacks', []),
          mockApiService.get('mm_status', 'OPEN'),
          mockApiService.get('mm_admin_user', ''),
          mockApiService.get('mm_admin_pass', '2606'),
          mockApiService.get('mm_admin_sq', ''),
          mockApiService.get('mm_admin_sa', ''),
          mockApiService.get('mm_contact', DEFAULT_CONTACT),
          mockApiService.get('mm_groceries', INITIAL_GROCERIES),
          mockApiService.get('mm_expenses', INITIAL_EXPENSES),
          mockApiService.get('mm_holidays', INITIAL_HOLIDAYS)
        ]);

        setStudents(s);
        setMenu(m);
        setNotices(n);
        setPolls(p);
        setFeedbacks(f);
        setCanteenStatus(status as any);
        setAdminUsername(userNm);
        setAdminPassword(pass);
        setAdminSecurityQuestion(sQ);
        setAdminSecurityAnswer(sA);
        setCanteenContact(contact);
        setGroceries(g);
        setExpenses(e);
        setHolidays(h);

        const storedUserStr = localStorage.getItem('messmate_user');
        if (storedUserStr) {
          const parsed = JSON.parse(storedUserStr);
          if (parsed.role === UserRole.STUDENT && parsed.data) {
            const freshData = s.find((student: Student) => student.rollNo === parsed.data.rollNo);
            if (freshData) parsed.data = freshData;
          }
          setUser(parsed);
        }
      } catch (err) {
        console.error("Initialization failed", err);
      } finally {
        setIsLoading(false);
      }
    };
    initData();
  }, []);

  // Persistent Sync Effect
  useEffect(() => {
    if (isLoading) return;
    const sync = async () => {
      setIsSyncing(true);
      
      // Save locally
      const localPromises = [
        mockApiService.post('mm_students', students),
        mockApiService.post('mm_menu', menu),
        mockApiService.post('mm_notices', notices),
        mockApiService.post('mm_polls', polls),
        mockApiService.post('mm_feedbacks', feedbacks),
        mockApiService.post('mm_status', canteenStatus),
        mockApiService.post('mm_admin_user', adminUsername),
        mockApiService.post('mm_admin_pass', adminPassword),
        mockApiService.post('mm_admin_sq', adminSecurityQuestion),
        mockApiService.post('mm_admin_sa', adminSecurityAnswer),
        mockApiService.post('mm_contact', canteenContact),
        mockApiService.post('mm_db_config', dbConfig),
        mockApiService.post('mm_groceries', groceries),
        mockApiService.post('mm_expenses', expenses),
        mockApiService.post('mm_holidays', holidays)
      ];

      // If Cloud enabled, try syncing there too
      if (dbConfig.isEnabled && dbConfig.baseUrl) {
        try {
          await apiService.postWithConfig('/sync', { 
            students, menu, notices, polls, feedbacks, status: canteenStatus, groceries, expenses, holidays
          }, dbConfig);
          setDbStatus('CLOUD');
        } catch (e) {
          setDbStatus('ERROR');
        }
      }

      await Promise.all(localPromises);
      setIsSyncing(false);
    };
    const timer = setTimeout(sync, 1500);
    return () => clearTimeout(timer);
  }, [students, menu, notices, polls, feedbacks, canteenStatus, adminUsername, adminPassword, adminSecurityQuestion, adminSecurityAnswer, canteenContact, dbConfig, isLoading, groceries, expenses, holidays]);

  const handleUpdateStudent = (updatedStudent: Student) => {
    setStudents(prev => prev.map(s => s.rollNo === updatedStudent.rollNo ? updatedStudent : s));
    if (user?.role === UserRole.STUDENT && user.data?.rollNo === updatedStudent.rollNo) {
      const newUser = { ...user, data: updatedStudent };
      setUser(newUser);
      localStorage.setItem('messmate_user', JSON.stringify(newUser));
    }
  };

  const handleLogin = (role: UserRole, id?: string, password?: string) => {
    let userData: Student | null = null;
    if (role === UserRole.OWNER) {
      if (id?.toLowerCase() !== adminUsername.toLowerCase() || password !== adminPassword) {
        alert("Invalid Admin credentials.");
        return;
      }
    } else if (role === UserRole.STUDENT) {
      const found = students.find(s => s.rollNo === id?.toUpperCase());
      if (!found) {
        alert("Student ID not recognized in database.");
        return;
      }
      if (password && found.password !== password) {
        alert("Invalid password.");
        return;
      }
      userData = found;
    }
    const newUser = { role, data: userData };
    setUser(newUser);
    localStorage.setItem('messmate_user', JSON.stringify(newUser));
    setView('DASHBOARD');
  };

  const handleSetupAdmin = (userNm: string, pass: string, sQ: string, sA: string) => {
    setAdminUsername(userNm);
    setAdminPassword(pass);
    setAdminSecurityQuestion(sQ);
    setAdminSecurityAnswer(sA);
    const newUser = { role: UserRole.OWNER, data: null };
    setUser(newUser);
    localStorage.setItem('messmate_user', JSON.stringify(newUser));
    setView('DASHBOARD');
  };

  const handleLogout = () => {
    setUser(null);
    localStorage.removeItem('messmate_user');
    setView('DASHBOARD');
  };

  const handleHolidayAction = (holidayId: string, action: 'APPROVE' | 'REJECT') => {
    setHolidays(prev => prev.map(h => {
      if (h.id === holidayId) {
        const newStatus = action === 'APPROVE' ? 'APPROVED' : 'REJECTED';
        if (action === 'APPROVE') {
          // Extend subscription
          const student = students.find(s => s.rollNo === h.studentRollNo);
          if (student) {
            const start = new Date(h.startDate);
            const end = new Date(h.endDate);
            const diffDays = Math.ceil((end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24)) + 1;
            
            const newExpiry = new Date(student.expiryDate);
            newExpiry.setDate(newExpiry.getDate() + diffDays);
            
            const updatedStudent: Student = {
              ...student,
              remainingDays: student.remainingDays + diffDays,
              expiryDate: newExpiry.toISOString().split('T')[0]
            };
            handleUpdateStudent(updatedStudent);
          }
        }
        return { ...h, status: newStatus as any };
      }
      return h;
    }));
  };

  if (isLoading) {
    return (
      <div className="h-screen w-full flex flex-col items-center justify-center bg-slate-950">
        <div className="w-16 h-16 border-4 border-slate-800 border-t-orange-500 rounded-full animate-spin mb-4"></div>
        <p className="text-slate-400 font-medium animate-pulse">Establishing Secure Connection...</p>
      </div>
    );
  }

  if (!user) {
    return (
      <Login 
        onLogin={handleLogin} 
        onSetupAdmin={handleSetupAdmin}
        adminConfig={{
          isConfigured: !!adminUsername,
          securityQuestion: adminSecurityQuestion,
          securityAnswer: adminSecurityAnswer,
          onResetPassword: (newPass) => setAdminPassword(newPass)
        }} 
      />
    );
  }

  const renderView = () => {
    if (user.role === UserRole.OWNER) {
      switch (view) {
        case 'DASHBOARD': return (
          <AdminDashboard 
            stats={{ total: students.length, unpaid: students.filter(s => !s.membershipActive).length }} 
            notices={notices} 
            polls={polls} 
            feedbacks={feedbacks} 
            canteenStatus={canteenStatus} 
            setCanteenStatus={setCanteenStatus} 
            adminConfig={{
              username: adminUsername,
              setUsername: setAdminUsername,
              password: adminPassword,
              setPassword: setAdminPassword,
              securityQuestion: adminSecurityQuestion,
              setSecurityQuestion: setAdminSecurityQuestion,
              securityAnswer: adminSecurityAnswer,
              setSecurityAnswer: setAdminSecurityAnswer
            }}
            contact={canteenContact} 
            setContact={setCanteenContact}
            dbConfig={dbConfig}
            setDbConfig={setDbConfig}
            holidays={holidays}
            onHolidayAction={handleHolidayAction}
            students={students}
          />
        );
        case 'MENU': return <MenuManager menu={menu} setMenu={setMenu} />;
        case 'STUDENTS': return <StudentManager students={students} setStudents={setStudents} />;
        case 'POLLS': return <PollManager polls={polls} setPolls={setPolls} />;
        case 'FEEDBACK': return <FeedbackList feedbacks={feedbacks} />;
        case 'NOTICES': return <NoticeManager notices={notices} setNotices={setNotices} />;
        case 'REPORTS': return <Reports students={students} feedbacks={feedbacks} fee={canteenContact.membershipFee} />;
        case 'STOCK': return <StockManager groceries={groceries} setGroceries={setGroceries} />;
        case 'EXPENSES': return <ExpenseAnalyzer expenses={expenses} setExpenses={setExpenses} students={students} />;
        default: return null;
      }
    } else {
      if (!user.data) { handleLogout(); return null; }
      switch (view) {
        case 'DASHBOARD': return <StudentDashboard student={user.data} notices={notices} canteenStatus={canteenStatus} updateStudent={handleUpdateStudent} contact={canteenContact} menu={menu} />;
        case 'MENU': return <StudentMenu menu={menu} />;
        case 'POLLS': return <StudentPolls polls={polls} setPolls={setPolls} studentRollNo={user.data.rollNo} />;
        case 'PAYMENTS': return <StudentPayments student={user.data} setStudents={setStudents} allStudents={students} contact={canteenContact} />;
        case 'FEEDBACK': return <StudentFeedback rollNo={user.data.rollNo} name={user.data.name} onSubmit={(f) => setFeedbacks([f, ...feedbacks])} />;
        case 'HOLIDAYS': return <HolidayManager student={user.data} holidays={holidays} setHolidays={setHolidays} />;
        case 'CHATBOT': return <AIChatbot student={user.data} menu={menu} />;
        default: return null;
      }
    }
  };

  return (
    <div className="flex h-screen bg-slate-950 overflow-hidden text-slate-100">
      <Sidebar role={user.role} currentView={view} setView={setView} onLogout={handleLogout} />
      <main className="flex-1 overflow-y-auto p-4 md:p-8">
        <header className="mb-8 flex justify-between items-center bg-slate-900/50 backdrop-blur-md p-4 rounded-3xl border border-slate-800 shadow-xl md:bg-transparent md:p-0 md:border-0 md:shadow-none">
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl md:text-2xl font-bold text-slate-50">
                {view.charAt(0) + view.slice(1).toLowerCase().replace('_', ' ')}
              </h1>
              {isSyncing && (
                <span className="text-[10px] bg-slate-800 text-orange-400 px-2 py-0.5 rounded-full animate-pulse">
                  Syncing...
                </span>
              )}
            </div>
            <p className="text-slate-400 text-xs md:text-sm">Logged in as {user.role === UserRole.OWNER ? 'Canteen Admin' : user.data?.name}</p>
          </div>
          <div className="flex items-center gap-2 md:gap-4">
             <div className="flex flex-col items-end mr-2">
                <span className={`text-[10px] font-bold tracking-tighter ${dbStatus === 'CLOUD' ? 'text-emerald-500' : dbStatus === 'ERROR' ? 'text-red-500' : 'text-slate-500'}`}>
                  {dbStatus === 'CLOUD' ? '● CLOUD CONNECTED' : dbStatus === 'ERROR' ? '● CLOUD OFFLINE' : '● LOCAL STORAGE'}
                </span>
             </div>
             {user.role === UserRole.STUDENT && (
               <span className={`text-[10px] md:text-xs font-bold px-3 py-1 rounded-full border ${canteenStatus === 'OPEN' ? 'border-green-900 bg-green-900/20 text-green-400' : canteenStatus === 'BUSY' ? 'border-amber-900 bg-amber-900/20 text-amber-400' : 'border-red-900 bg-red-900/20 text-red-400'}`}>
                 • CANTEEN {canteenStatus}
               </span>
             )}
            <span className="bg-orange-600/20 text-orange-500 border border-orange-600/30 px-3 py-1 rounded-full text-[10px] md:text-xs font-semibold uppercase tracking-wider">
              {user.role}
            </span>
          </div>
        </header>
        {renderView()}
      </main>
    </div>
  );
};

export default App;