export enum UserRole {
  STUDENT = 'STUDENT',
  OWNER = 'OWNER'
}

export enum SubscriptionPlan {
  DAILY = 'DAILY', // ₹70
  MONTHLY_SINGLE = 'MONTHLY_SINGLE', // ₹1500
  MONTHLY_DOUBLE = 'MONTHLY_DOUBLE' // ₹2700
}

export enum Language {
  ENGLISH = 'en',
  HINDI = 'hi',
  MARATHI = 'mr'
}

export interface MenuItem {
  id: string;
  name: string;
  type: 'Breakfast' | 'Lunch' | 'Dinner' | 'Snack';
  description?: string;
  isVegetarian: boolean;
  isFlashSale?: boolean;
  salePrice?: number;
  nutrition?: {
    calories: number;
    protein: number;
    carbs: number;
    fats: number;
  };
}

export interface Poll {
  id: string;
  question: string;
  options: { id: string; text: string; votes: number }[];
  isActive: boolean;
  votedBy: string[];
}

export interface AttendanceRecord {
  date: string;
  status: 'PRESENT' | 'ABSENT' | 'HOLIDAY';
}

export interface HolidayApplication {
  id: string;
  studentRollNo: string;
  startDate: string;
  endDate: string;
  reason: string;
  status: 'PENDING' | 'APPROVED' | 'REJECTED';
  appliedAt: string;
}

export interface Student {
  rollNo: string;
  name: string;
  hostel: string;
  password?: string;
  email?: string;
  membershipActive: boolean;
  subscriptionPlan?: SubscriptionPlan;
  remainingDays: number;
  expiryDate: string;
  lastPaymentDate: string;
  payments: Payment[];
  rsvpStatus?: 'YES' | 'NO' | 'PENDING';
  attendance: AttendanceRecord[];
  ecoCredits: number;
  language: Language;
}

export interface Payment {
  id: string;
  amount: number;
  date: string;
  month: string;
  status: 'PAID' | 'UNPAID' | 'PENDING';
  plan: SubscriptionPlan;
}

export interface Feedback {
  id: string;
  studentRollNo: string;
  studentName: string;
  rating: number;
  comment: string;
  date: string;
}

export interface Notice {
  id: string;
  title: string;
  content: string;
  date: string;
  isImportant: boolean;
}

export interface GroceryItem {
  id: string;
  name: string;
  quantity: number;
  unit: string;
  minLimit: number;
  lastRestocked: string;
}

export interface ExpenseRecord {
  id: string;
  category: 'GROCERY' | 'ELECTRICITY' | 'GAS' | 'SALARY' | 'OTHER';
  amount: number;
  description: string;
  date: string;
}

export interface CanteenContact {
  phone: string;
  upiId: string;
  qrCode?: string; // Base64 string
  ownerName: string;
  membershipFee: number;
}

export type ViewState = 
  | 'DASHBOARD' 
  | 'MENU' 
  | 'POLLS' 
  | 'PAYMENTS' 
  | 'FEEDBACK' 
  | 'STUDENTS' 
  | 'NOTICES' 
  | 'REPORTS' 
  | 'CHECKIN'
  | 'STOCK'
  | 'EXPENSES'
  | 'HOLIDAYS'
  | 'SETTINGS'
  | 'CHATBOT';
