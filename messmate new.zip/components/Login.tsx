import React, { useState, useEffect } from 'react';
import { UserRole } from '../types';

interface LoginProps {
  onLogin: (role: UserRole, id?: string, password?: string) => void;
  onSetupAdmin: (username: string, pass: string, sq: string, sa: string) => void;
  adminConfig: {
    isConfigured: boolean;
    securityQuestion: string;
    securityAnswer: string;
    onResetPassword: (newPass: string) => void;
  };
}

const SECURITY_QUESTIONS = [
  "What was the name of your first school?",
  "What is your mother's maiden name?",
  "What was your first pet's name?",
  "What city were you born in?",
  "What is your favorite food from the canteen?"
];

const Login: React.FC<LoginProps> = ({ onLogin, onSetupAdmin, adminConfig }) => {
  const [role, setRole] = useState<UserRole>(UserRole.STUDENT);
  const [userId, setUserId] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  
  // States for flows
  const [flow, setFlow] = useState<'LOGIN' | 'SETUP_ACTIVATION' | 'SETUP_PROFILE' | 'FORGOT_PASSWORD' | 'RESET_PASSWORD'>('LOGIN');
  const [activationCode, setActivationCode] = useState('');
  const [setupData, setSetupData] = useState({ username: '', password: '', sq: SECURITY_QUESTIONS[0], sa: '' });
  const [recoveryData, setRecoveryData] = useState({ answer: '', newPass: '' });
  
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);

  useEffect(() => {
    window.addEventListener('beforeinstallprompt', (e) => {
      e.preventDefault();
      setDeferredPrompt(e);
    });
  }, []);

  const handleInstallClick = async () => {
    if (!deferredPrompt) return;
    deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    if (outcome === 'accepted') {
      setDeferredPrompt(null);
    }
  };

  const handleAdminTab = () => {
    setRole(UserRole.OWNER);
    if (!adminConfig.isConfigured) {
      setFlow('SETUP_ACTIVATION');
    } else {
      setFlow('LOGIN');
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (role === UserRole.STUDENT) {
      if (!userId) { alert("Please enter Roll No"); return; }
      onLogin(UserRole.STUDENT, userId);
    } else {
      if (flow === 'LOGIN') {
        if (!userId || !password) { alert("Enter both Username and Password"); return; }
        onLogin(UserRole.OWNER, userId, password);
      } else if (flow === 'SETUP_ACTIVATION') {
        if (activationCode === '2606') {
          setFlow('SETUP_PROFILE');
        } else {
          alert("Invalid Activation Code. Please check with your developer.");
        }
      } else if (flow === 'SETUP_PROFILE') {
        if (!setupData.username || !setupData.password || !setupData.sa) {
          alert("Please fill all profile fields.");
          return;
        }
        onSetupAdmin(setupData.username, setupData.password, setupData.sq, setupData.sa);
      } else if (flow === 'FORGOT_PASSWORD') {
        if (recoveryData.answer.toLowerCase() === adminConfig.securityAnswer.toLowerCase()) {
          setFlow('RESET_PASSWORD');
        } else {
          alert("Incorrect answer to security question.");
        }
      } else if (flow === 'RESET_PASSWORD') {
        if (!recoveryData.newPass) { alert("Enter new password"); return; }
        adminConfig.onResetPassword(recoveryData.newPass);
        alert("Password reset successful. Please login.");
        setFlow('LOGIN');
        setPassword('');
      }
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-950 p-4">
      {/* Dynamic Background */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none opacity-30">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-orange-600/20 blur-[120px] rounded-full"></div>
        <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-indigo-600/20 blur-[120px] rounded-full"></div>
      </div>

      <div className="bg-slate-900 p-8 rounded-[32px] shadow-2xl w-full max-w-md relative border border-slate-800 z-10 transition-all">
        {deferredPrompt && (
          <button 
            onClick={handleInstallClick}
            className="absolute -top-12 left-1/2 -translate-x-1/2 bg-white/10 hover:bg-white/20 text-white text-[10px] font-bold py-2 px-4 rounded-full backdrop-blur-md border border-white/20 transition-all flex items-center gap-2"
          >
            <span>📲</span> Install MessMate App
          </button>
        )}

        <div className="text-center mb-8">
          <div className="bg-orange-600/20 w-16 h-16 rounded-3xl flex items-center justify-center mx-auto mb-4 border border-orange-600/30">
             <svg className="w-8 h-8 text-orange-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.168.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"></path></svg>
          </div>
          <h1 className="text-3xl font-bold text-white tracking-tight">MessMate</h1>
          <p className="text-slate-400 text-sm mt-1">Smart Canteen Ecosystem</p>
        </div>

        <div className="flex bg-slate-800 rounded-2xl p-1.5 mb-8 border border-slate-700">
          <button
            onClick={() => { setRole(UserRole.STUDENT); setFlow('LOGIN'); }}
            className={`flex-1 py-2.5 rounded-xl text-sm font-bold transition-all ${role === UserRole.STUDENT ? 'bg-orange-600 text-white shadow-lg' : 'text-slate-400 hover:text-slate-200'}`}
          >
            Student
          </button>
          <button
            onClick={handleAdminTab}
            className={`flex-1 py-2.5 rounded-xl text-sm font-bold transition-all ${role === UserRole.OWNER ? 'bg-orange-600 text-white shadow-lg' : 'text-slate-400 hover:text-slate-200'}`}
          >
            Admin
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">
          {role === UserRole.STUDENT ? (
            <div>
              <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-2 ml-1">Roll Number / ID</label>
              <input
                type="text"
                value={userId}
                onChange={(e) => setUserId(e.target.value.toUpperCase())}
                placeholder="e.g. 2024CS01"
                className="w-full bg-slate-800 px-5 py-4 rounded-2xl border border-slate-700 focus:outline-none focus:ring-2 focus:ring-orange-500 transition-all text-white placeholder:text-slate-600"
              />
            </div>
          ) : (
            <>
              {flow === 'SETUP_ACTIVATION' && (
                <div className="animate-in fade-in slide-in-from-right-4">
                  <h3 className="text-sm font-bold text-orange-400 mb-2">Admin Activation Required</h3>
                  <p className="text-xs text-slate-400 mb-4 leading-relaxed">System is not configured. Enter the master code provided during installation.</p>
                  <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-2 ml-1">Activation Code</label>
                  <input
                    type="password"
                    value={activationCode}
                    onChange={(e) => setActivationCode(e.target.value)}
                    placeholder="Enter 4-digit code"
                    className="w-full bg-slate-800 px-5 py-4 rounded-2xl border border-slate-700 focus:outline-none focus:ring-2 focus:ring-orange-500 text-white"
                  />
                </div>
              )}

              {flow === 'SETUP_PROFILE' && (
                <div className="space-y-4 animate-in fade-in slide-in-from-right-4">
                  <h3 className="text-sm font-bold text-emerald-400 mb-1">Create Admin Profile</h3>
                  <p className="text-[10px] text-slate-400 mb-4 leading-relaxed uppercase tracking-wider">Set your unique credentials for the first time.</p>
                  
                  <div>
                    <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1.5 ml-1">New Username</label>
                    <input
                      type="text"
                      className="w-full bg-slate-800 px-4 py-3 rounded-xl border border-slate-700 text-white text-sm outline-none focus:ring-2 focus:ring-emerald-500"
                      value={setupData.username}
                      onChange={e => setSetupData({...setupData, username: e.target.value})}
                      placeholder="e.g. canteen_boss"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1.5 ml-1">New Password</label>
                    <input
                      type="password"
                      className="w-full bg-slate-800 px-4 py-3 rounded-xl border border-slate-700 text-white text-sm outline-none focus:ring-2 focus:ring-emerald-500"
                      value={setupData.password}
                      onChange={e => setSetupData({...setupData, password: e.target.value})}
                      placeholder="Strong password"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1.5 ml-1">Security Question</label>
                    <select
                      className="w-full bg-slate-800 px-4 py-3 rounded-xl border border-slate-700 text-white text-xs outline-none focus:ring-2 focus:ring-emerald-500"
                      value={setupData.sq}
                      onChange={e => setSetupData({...setupData, sq: e.target.value})}
                    >
                      {SECURITY_QUESTIONS.map(q => <option key={q} value={q}>{q}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1.5 ml-1">Your Answer</label>
                    <input
                      type="text"
                      className="w-full bg-slate-800 px-4 py-3 rounded-xl border border-slate-700 text-white text-sm outline-none focus:ring-2 focus:ring-emerald-500"
                      value={setupData.sa}
                      onChange={e => setSetupData({...setupData, sa: e.target.value})}
                      placeholder="Case insensitive"
                    />
                  </div>
                </div>
              )}

              {flow === 'LOGIN' && (
                <div className="space-y-4 animate-in fade-in slide-in-from-bottom-2">
                  <div>
                    <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-2 ml-1">Admin Username</label>
                    <input
                      type="text"
                      value={userId}
                      onChange={(e) => setUserId(e.target.value)}
                      className="w-full bg-slate-800 px-5 py-4 rounded-2xl border border-slate-700 focus:outline-none focus:ring-2 focus:ring-orange-500 text-white placeholder:text-slate-600"
                      placeholder="Enter username"
                    />
                  </div>
                  <div className="relative">
                    <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-2 ml-1">Password</label>
                    <input
                      type={showPassword ? "text" : "password"}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="w-full bg-slate-800 px-5 py-4 rounded-2xl border border-slate-700 focus:outline-none focus:ring-2 focus:ring-orange-500 text-white placeholder:text-slate-600"
                      placeholder="Enter password"
                    />
                    <button 
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-4 top-[42px] text-slate-500 hover:text-slate-300"
                    >
                      {showPassword ? "🙈" : "👁️"}
                    </button>
                  </div>
                  <div className="text-right">
                    <button 
                      type="button" 
                      onClick={() => setFlow('FORGOT_PASSWORD')}
                      className="text-[10px] font-bold text-slate-500 hover:text-orange-500 uppercase tracking-wider transition-colors"
                    >
                      Forgot Password?
                    </button>
                  </div>
                </div>
              )}

              {flow === 'FORGOT_PASSWORD' && (
                <div className="space-y-4 animate-in fade-in zoom-in-95">
                  <h3 className="text-sm font-bold text-orange-400">Security Verification</h3>
                  <p className="text-xs text-slate-200 bg-slate-800/50 p-4 rounded-xl border border-slate-800">{adminConfig.securityQuestion}</p>
                  <div>
                    <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-2 ml-1">Answer</label>
                    <input
                      type="text"
                      value={recoveryData.answer}
                      onChange={(e) => setRecoveryData({...recoveryData, answer: e.target.value})}
                      className="w-full bg-slate-800 px-5 py-4 rounded-2xl border border-slate-700 focus:outline-none focus:ring-2 focus:ring-orange-500 text-white"
                      placeholder="Your secret answer"
                    />
                  </div>
                  <button type="button" onClick={() => setFlow('LOGIN')} className="text-[10px] text-slate-500 hover:underline">Back to Login</button>
                </div>
              )}

              {flow === 'RESET_PASSWORD' && (
                <div className="space-y-4 animate-in fade-in slide-in-from-bottom-2">
                  <h3 className="text-sm font-bold text-emerald-400">Set New Password</h3>
                  <div>
                    <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-2 ml-1">New Password</label>
                    <input
                      type="password"
                      value={recoveryData.newPass}
                      onChange={(e) => setRecoveryData({...recoveryData, newPass: e.target.value})}
                      className="w-full bg-slate-800 px-5 py-4 rounded-2xl border border-slate-700 focus:outline-none focus:ring-2 focus:ring-orange-500 text-white"
                      placeholder="New strong password"
                    />
                  </div>
                </div>
              )}
            </>
          )}

          <button
            type="submit"
            className="w-full bg-orange-600 hover:bg-orange-700 text-white font-black py-4 rounded-2xl shadow-xl shadow-orange-900/20 transition-all transform hover:-translate-y-0.5 active:scale-95 uppercase tracking-widest"
          >
            {flow === 'LOGIN' ? 'Continue' : flow === 'SETUP_ACTIVATION' ? 'Verify Code' : flow === 'SETUP_PROFILE' ? 'Save & Start' : flow === 'FORGOT_PASSWORD' ? 'Verify Answer' : 'Reset & Save'}
          </button>
        </form>

        <p className="mt-8 text-center text-[11px] text-slate-600 uppercase tracking-[2px] font-medium">
          Authorized Campus Access
        </p>
      </div>
    </div>
  );
};

export default Login;