import React from 'react';
import { UserRole, ViewState } from './types';

interface SidebarProps {
  role: UserRole;
  currentView: ViewState;
  setView: (v: ViewState) => void;
  onLogout: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ role, currentView, setView, onLogout }) => {
  const menuItems = role === UserRole.OWNER ? [
    { id: 'DASHBOARD', label: 'Dashboard', icon: '📊' },
    { id: 'MENU', label: 'Manage Menu', icon: '🍛' },
    { id: 'STUDENTS', label: 'Membership', icon: '👥' },
    { id: 'POLLS', label: 'Polls Manager', icon: '🗳️' },
    { id: 'NOTICES', label: 'Broadcasting', icon: '📢' },
    { id: 'FEEDBACK', label: 'Feedback', icon: '💬' },
    { id: 'REPORTS', label: 'Analytics', icon: '📈' },
  ] : [
    { id: 'DASHBOARD', label: 'Home', icon: '🏠' },
    { id: 'MENU', label: 'Today\'s Menu', icon: '🍛' },
    { id: 'POLLS', label: 'Food Polls', icon: '🗳️' },
    { id: 'PAYMENTS', label: 'Payments', icon: '💳' },
    { id: 'FEEDBACK', label: 'Give Feedback', icon: '💬' },
  ];

  return (
    <aside className="w-20 md:w-64 bg-slate-900 border-r border-slate-800 flex flex-col h-full shrink-0">
      <div className="p-6 border-b border-slate-800 flex items-center gap-3">
        <div className="w-10 h-10 bg-orange-600 rounded-xl flex items-center justify-center text-white font-bold text-xl shadow-lg shadow-orange-900/20">M</div>
        <span className="hidden md:block font-bold text-xl tracking-tight text-white">MessMate</span>
      </div>
      
      <nav className="flex-1 p-4 space-y-2 overflow-y-auto">
        {menuItems.map((item) => (
          <button
            key={item.id}
            onClick={() => setView(item.id as ViewState)}
            className={`w-full flex items-center gap-3 p-3 rounded-xl transition-all ${
              currentView === item.id 
                ? 'bg-orange-600/10 text-orange-500 font-semibold ring-1 ring-orange-500/20' 
                : 'text-slate-400 hover:bg-slate-800 hover:text-slate-200'
            }`}
          >
            <span className="text-xl">{item.icon}</span>
            <span className="hidden md:block">{item.label}</span>
          </button>
        ))}
      </nav>

      <div className="p-4 border-t border-slate-800">
        <button
          onClick={onLogout}
          className="w-full flex items-center gap-3 p-3 rounded-xl text-red-400 hover:bg-red-400/10 transition-all"
        >
          <span className="text-xl">🚪</span>
          <span className="hidden md:block font-medium">Logout</span>
        </button>
      </div>
    </aside>
  );
};

export default Sidebar;